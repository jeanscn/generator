create
    definer = root@`%` function organizationChildIds(rootId varchar(36)) returns varchar(1000)
begin 
	declare result varchar(1000);
	declare tempChild varchar(1000);
	set result = '';
	set tempChild =cast(rootId as char);
	while tempChild is not null do
		if tempChild!=rootId then
			set result = concat(result,',',tempChild);
		end if;	
		select group_concat(ID_) into tempChild from ORG_ORGANIZATION where find_in_set(PARENT_ID,tempChild)>0;
	end while;
	return result;
end;

