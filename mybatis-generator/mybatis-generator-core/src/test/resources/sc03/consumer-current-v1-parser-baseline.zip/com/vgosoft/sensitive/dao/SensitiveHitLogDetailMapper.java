package com.vgosoft.sensitive.dao;

import com.vgosoft.sensitive.codegen.dao.GenSensitiveHitLogDetailMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SensitiveHitLogDetailMapper extends GenSensitiveHitLogDetailMapper {
}