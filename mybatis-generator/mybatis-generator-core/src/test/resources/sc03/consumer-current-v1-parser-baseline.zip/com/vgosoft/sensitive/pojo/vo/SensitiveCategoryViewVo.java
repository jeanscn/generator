package com.vgosoft.sensitive.pojo.vo;

import com.vgosoft.core.annotation.DictEnum;
import com.vgosoft.sensitive.pojo.abs.AbstractSensitiveCategoryVo;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serial;
import java.util.Date;
import lombok.*;

@Data
@ToString(callSuper = true)
@Schema(name = "SensitiveCategoryViewVo", description = "敏感词分类管理", implementation = AbstractSensitiveCategoryVo.class)
public class SensitiveCategoryViewVo extends AbstractSensitiveCategoryVo {
    @Serial
    private static final long serialVersionUID = 1L;

    private Integer deleteFlag;

    private Date created;

    private Date modified;

    private String createdId;

    private String modifiedId;

    @DictEnum(value = "com.vgosoft.core.constant.enums.core.CommonStatusEnum", source = "state")
    private String stateText = "-";
}