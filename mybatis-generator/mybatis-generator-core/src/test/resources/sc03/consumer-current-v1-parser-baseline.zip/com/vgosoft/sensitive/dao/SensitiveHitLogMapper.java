package com.vgosoft.sensitive.dao;

import com.vgosoft.sensitive.codegen.dao.GenSensitiveHitLogMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SensitiveHitLogMapper extends GenSensitiveHitLogMapper {
}