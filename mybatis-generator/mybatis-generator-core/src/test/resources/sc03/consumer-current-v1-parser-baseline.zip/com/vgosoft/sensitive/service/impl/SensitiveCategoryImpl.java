package com.vgosoft.sensitive.service.impl;

import static com.vgosoft.core.constant.CacheConstant.CACHE_MANAGER_NAME;

import com.vgosoft.sensitive.codegen.service.impl.AbstractSensitiveCategoryImpl;
import com.vgosoft.sensitive.dao.SensitiveCategoryMapper;
import com.vgosoft.sensitive.service.ISensitiveCategory;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

@CacheConfig(cacheManager = CACHE_MANAGER_NAME)
@Service("sensitiveCategoryImpl")
@Primary
public class SensitiveCategoryImpl extends AbstractSensitiveCategoryImpl implements ISensitiveCategory {
    public SensitiveCategoryImpl(SensitiveCategoryMapper mapper) {
        super(mapper);
    }
}