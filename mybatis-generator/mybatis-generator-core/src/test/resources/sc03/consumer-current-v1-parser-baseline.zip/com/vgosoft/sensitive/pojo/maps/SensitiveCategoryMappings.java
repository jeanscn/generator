package com.vgosoft.sensitive.pojo.maps;

import com.vgosoft.sensitive.entity.SensitiveCategory;
import com.vgosoft.sensitive.pojo.vo.SensitiveCategoryCreateVo;
import com.vgosoft.sensitive.pojo.vo.SensitiveCategoryRequestVo;
import com.vgosoft.sensitive.pojo.vo.SensitiveCategoryUpdateVo;
import com.vgosoft.sensitive.pojo.vo.SensitiveCategoryViewVo;
import com.vgosoft.sensitive.pojo.vo.SensitiveCategoryVo;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring",unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface SensitiveCategoryMappings {
    /** 
     * 将SensitiveCategoryVo转换为SensitiveCategory
     * @param sensitiveCategoryVo 待转换的源对象
     * @return SensitiveCategory 转换后的目标对象
     * 提示 - @VCF.generated
    */
    SensitiveCategory fromSensitiveCategoryVo(SensitiveCategoryVo sensitiveCategoryVo);

    /** 
     * 将SensitiveCategory转换为SensitiveCategoryVo
     * @param sensitiveCategory 待转换的源对象
     * @return SensitiveCategoryVo 转换后的目标对象
     * 提示 - @VCF.generated
    */
    SensitiveCategoryVo toSensitiveCategoryVo(SensitiveCategory sensitiveCategory);

    /** 
     * 将SensitiveCategoryVo转换为SensitiveCategory
     * @param sensitiveCategoryVos 待转换的源对象
     * @return List<SensitiveCategory> 转换后的目标对象集合
     * 提示 - @VCF.generated
    */
    List<SensitiveCategory> fromSensitiveCategoryVos(List<SensitiveCategoryVo> sensitiveCategoryVos);

    /** 
     * 将SensitiveCategory转换为SensitiveCategoryVo
     * @param sensitiveCategorys 待转换的源对象
     * @return List<SensitiveCategoryVo> 转换后的目标对象集合
     * 提示 - @VCF.generated
    */
    List<SensitiveCategoryVo> toSensitiveCategoryVos(List<SensitiveCategory> sensitiveCategorys);

    /** 
     * 将SensitiveCategoryCreateVo转换为SensitiveCategory
     * @param sensitiveCategoryCreateVo 待转换的源对象
     * @return SensitiveCategory 转换后的目标对象
     * 提示 - @VCF.generated
    */
    SensitiveCategory fromSensitiveCategoryCreateVo(SensitiveCategoryCreateVo sensitiveCategoryCreateVo);

    /** 
     * 将SensitiveCategoryCreateVo转换为SensitiveCategory
     * @param sensitiveCategoryCreateVos 待转换的源对象
     * @return List<SensitiveCategory> 转换后的目标对象集合
     * 提示 - @VCF.generated
    */
    List<SensitiveCategory> fromSensitiveCategoryCreateVos(List<SensitiveCategoryCreateVo> sensitiveCategoryCreateVos);

    /** 
     * 将SensitiveCategoryUpdateVo转换为SensitiveCategory
     * @param sensitiveCategoryUpdateVo 待转换的源对象
     * @return SensitiveCategory 转换后的目标对象
     * 提示 - @VCF.generated
    */
    SensitiveCategory fromSensitiveCategoryUpdateVo(SensitiveCategoryUpdateVo sensitiveCategoryUpdateVo);

    /** 
     * 将SensitiveCategoryUpdateVo转换为SensitiveCategory
     * @param sensitiveCategoryUpdateVos 待转换的源对象
     * @return List<SensitiveCategory> 转换后的目标对象集合
     * 提示 - @VCF.generated
    */
    List<SensitiveCategory> fromSensitiveCategoryUpdateVos(List<SensitiveCategoryUpdateVo> sensitiveCategoryUpdateVos);

    /** 
     * 将SensitiveCategory转换为SensitiveCategoryViewVo
     * @param sensitiveCategory 待转换的源对象
     * @return SensitiveCategoryViewVo 转换后的目标对象
     * 提示 - @VCF.generated
    */
    SensitiveCategoryViewVo toSensitiveCategoryViewVo(SensitiveCategory sensitiveCategory);

    /** 
     * 将SensitiveCategory转换为SensitiveCategoryViewVo
     * @param sensitiveCategorys 待转换的源对象
     * @return List<SensitiveCategoryViewVo> 转换后的目标对象集合
     * 提示 - @VCF.generated
    */
    List<SensitiveCategoryViewVo> toSensitiveCategoryViewVos(List<SensitiveCategory> sensitiveCategorys);

    /** 
     * 将SensitiveCategoryRequestVo转换为SensitiveCategory
     * @param sensitiveCategoryRequestVo 待转换的源对象
     * @return SensitiveCategory 转换后的目标对象
     * 提示 - @VCF.generated
    */
    SensitiveCategory fromSensitiveCategoryRequestVo(SensitiveCategoryRequestVo sensitiveCategoryRequestVo);
}