package com.vgosoft.sensitive.service;

import com.vgosoft.sensitive.codegen.service.IGenSensitiveWord;

public interface ISensitiveWord extends IGenSensitiveWord {
}