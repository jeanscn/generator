package com.vgosoft.sensitive.dao;

import com.vgosoft.sensitive.codegen.dao.GenSensitiveImportPreviewMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SensitiveImportPreviewMapper extends GenSensitiveImportPreviewMapper {
}