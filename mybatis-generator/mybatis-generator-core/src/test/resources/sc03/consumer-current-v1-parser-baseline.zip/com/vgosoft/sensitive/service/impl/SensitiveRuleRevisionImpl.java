package com.vgosoft.sensitive.service.impl;

import com.vgosoft.sensitive.codegen.service.impl.AbstractSensitiveRuleRevisionImpl;
import com.vgosoft.sensitive.dao.SensitiveRuleRevisionMapper;
import com.vgosoft.sensitive.service.ISensitiveRuleRevision;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

@Service("sensitiveRuleRevisionImpl")
@Primary
public class SensitiveRuleRevisionImpl extends AbstractSensitiveRuleRevisionImpl implements ISensitiveRuleRevision {
    public SensitiveRuleRevisionImpl(SensitiveRuleRevisionMapper mapper) {
        super(mapper);
    }
}