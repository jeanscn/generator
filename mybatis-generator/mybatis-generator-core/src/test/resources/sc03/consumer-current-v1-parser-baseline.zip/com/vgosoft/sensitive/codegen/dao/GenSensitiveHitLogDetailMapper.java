package com.vgosoft.sensitive.codegen.dao;

import com.baomidou.mybatisplus.core.mapper.Mapper;
import com.vgosoft.mybatis.inf.MBGMapperInterface;
import com.vgosoft.sensitive.entity.SensitiveHitLogDetail;
import com.vgosoft.sensitive.entity.SensitiveHitLogDetailExample;
import java.util.List;

public interface GenSensitiveHitLogDetailMapper extends MBGMapperInterface<SensitiveHitLogDetail, SensitiveHitLogDetailExample>, Mapper<SensitiveHitLogDetail> {
    int insertBatch(List<SensitiveHitLogDetail> sensitiveHitLogDetails);
}