package com.vgosoft.sensitive.codegen.dao;

import com.vgosoft.sensitive.entity.SensitiveWordExample;
import org.springframework.transaction.support.TransactionSynchronizationManager;

/**
 * 锁定查询的事务、分页和条件门禁，仅用于生成的独立锁定查询。
 * @author vgosoft
 */
public final class GenSensitiveWordMapperLockQueryGuard {
    /**
     * 验证非只读既有事务及无分页上下文，禁止绕过 Service 的直接 Mapper 调用。
     * @return 门禁验证通过
     * @throws IllegalStateException 无事务、只读事务或存在分页上下文
     */
    public static boolean requireSelectForUpdateTransaction() {
        if (!TransactionSynchronizationManager.isActualTransactionActive()
                || TransactionSynchronizationManager.isCurrentTransactionReadOnly()) {
            throw new IllegalStateException("锁定查询必须在非只读既有事务中执行");
        }
        if (com.github.pagehelper.PageHelper.getLocalPage() != null) {
            throw new IllegalStateException("锁定查询禁止 PageHelper 分页或排序上下文");
        }
        return true;
    }

    /**
     * 校验非空条件及内省列操作符白名单，拒绝原始 SQL、去重和任意排序。
     * @param example 非空标准查询条件
     * @return 门禁验证通过
     * @throws IllegalStateException 无事务、只读事务或存在分页上下文
     * @throws IllegalArgumentException 查询条件不符合锁定查询约束
     */
    public static boolean requireSelectForUpdateExample(SensitiveWordExample example) {
        requireSelectForUpdateTransaction();
        if (example == null || example.isDistinct() || example.getOrderByClause() != null
                || example.getOredCriteria() == null || example.getOredCriteria().isEmpty()) {
            throw new IllegalArgumentException("锁定查询要求非空条件，禁止 DISTINCT 和动态排序");
        }
        java.util.Set<String> allowed = new java.util.HashSet<>(java.util.Arrays.asList("sw.id_ is null", "sw.id_ is not null", "sw.id_ =", "sw.id_ <>", "sw.id_ >", "sw.id_ >=", "sw.id_ <", "sw.id_ <=", "sw.id_ like", "sw.id_ not like", "sw.id_ in", "sw.id_ not in", "sw.id_ between", "sw.id_ not between", "sw.delete_flag is null", "sw.delete_flag is not null", "sw.delete_flag =", "sw.delete_flag <>", "sw.delete_flag >", "sw.delete_flag >=", "sw.delete_flag <", "sw.delete_flag <=", "sw.delete_flag like", "sw.delete_flag not like", "sw.delete_flag in", "sw.delete_flag not in", "sw.delete_flag between", "sw.delete_flag not between", "sw.created_ is null", "sw.created_ is not null", "sw.created_ =", "sw.created_ <>", "sw.created_ >", "sw.created_ >=", "sw.created_ <", "sw.created_ <=", "sw.created_ like", "sw.created_ not like", "sw.created_ in", "sw.created_ not in", "sw.created_ between", "sw.created_ not between", "sw.modified_ is null", "sw.modified_ is not null", "sw.modified_ =", "sw.modified_ <>", "sw.modified_ >", "sw.modified_ >=", "sw.modified_ <", "sw.modified_ <=", "sw.modified_ like", "sw.modified_ not like", "sw.modified_ in", "sw.modified_ not in", "sw.modified_ between", "sw.modified_ not between", "sw.created_id is null", "sw.created_id is not null", "sw.created_id =", "sw.created_id <>", "sw.created_id >", "sw.created_id >=", "sw.created_id <", "sw.created_id <=", "sw.created_id like", "sw.created_id not like", "sw.created_id in", "sw.created_id not in", "sw.created_id between", "sw.created_id not between", "sw.modified_id is null", "sw.modified_id is not null", "sw.modified_id =", "sw.modified_id <>", "sw.modified_id >", "sw.modified_id >=", "sw.modified_id <", "sw.modified_id <=", "sw.modified_id like", "sw.modified_id not like", "sw.modified_id in", "sw.modified_id not in", "sw.modified_id between", "sw.modified_id not between", "sw.version_ is null", "sw.version_ is not null", "sw.version_ =", "sw.version_ <>", "sw.version_ >", "sw.version_ >=", "sw.version_ <", "sw.version_ <=", "sw.version_ like", "sw.version_ not like", "sw.version_ in", "sw.version_ not in", "sw.version_ between", "sw.version_ not between", "sw.state_ is null", "sw.state_ is not null", "sw.state_ =", "sw.state_ <>", "sw.state_ >", "sw.state_ >=", "sw.state_ <", "sw.state_ <=", "sw.state_ like", "sw.state_ not like", "sw.state_ in", "sw.state_ not in", "sw.state_ between", "sw.state_ not between", "sw.word_ is null", "sw.word_ is not null", "sw.word_ =", "sw.word_ <>", "sw.word_ >", "sw.word_ >=", "sw.word_ <", "sw.word_ <=", "sw.word_ like", "sw.word_ not like", "sw.word_ in", "sw.word_ not in", "sw.word_ between", "sw.word_ not between", "sw.word_hash_ is null", "sw.word_hash_ is not null", "sw.word_hash_ =", "sw.word_hash_ <>", "sw.word_hash_ >", "sw.word_hash_ >=", "sw.word_hash_ <", "sw.word_hash_ <=", "sw.word_hash_ like", "sw.word_hash_ not like", "sw.word_hash_ in", "sw.word_hash_ not in", "sw.word_hash_ between", "sw.word_hash_ not between", "sw.category_id is null", "sw.category_id is not null", "sw.category_id =", "sw.category_id <>", "sw.category_id >", "sw.category_id >=", "sw.category_id <", "sw.category_id <=", "sw.category_id like", "sw.category_id not like", "sw.category_id in", "sw.category_id not in", "sw.category_id between", "sw.category_id not between", "sw.strategy_ is null", "sw.strategy_ is not null", "sw.strategy_ =", "sw.strategy_ <>", "sw.strategy_ >", "sw.strategy_ >=", "sw.strategy_ <", "sw.strategy_ <=", "sw.strategy_ like", "sw.strategy_ not like", "sw.strategy_ in", "sw.strategy_ not in", "sw.strategy_ between", "sw.strategy_ not between", "sw.notes_ is null", "sw.notes_ is not null", "sw.notes_ =", "sw.notes_ <>", "sw.notes_ >", "sw.notes_ >=", "sw.notes_ <", "sw.notes_ <=", "sw.notes_ like", "sw.notes_ not like", "sw.notes_ in", "sw.notes_ not in", "sw.notes_ between", "sw.notes_ not between", "sw.category_cascade_disabled_ is null", "sw.category_cascade_disabled_ is not null", "sw.category_cascade_disabled_ =", "sw.category_cascade_disabled_ <>", "sw.category_cascade_disabled_ >", "sw.category_cascade_disabled_ >=", "sw.category_cascade_disabled_ <", "sw.category_cascade_disabled_ <=", "sw.category_cascade_disabled_ like", "sw.category_cascade_disabled_ not like", "sw.category_cascade_disabled_ in", "sw.category_cascade_disabled_ not in", "sw.category_cascade_disabled_ between", "sw.category_cascade_disabled_ not between"));
        boolean valid = false;
        for (SensitiveWordExample.Criteria criteria : example.getOredCriteria()) {
            if (criteria == null) { throw new IllegalArgumentException("锁定查询条件组不能为空"); }
            if (!criteria.isValid()) { continue; }
            for (SensitiveWordExample.Criterion criterion : criteria.getAllCriteria()) {
                if (criterion == null || !allowed.contains(criterion.getCondition())) {
                    throw new IllegalArgumentException("锁定查询只允许内省列的标准条件，禁止原始 SQL");
                }
                if (criterion.isListValue() && (!(criterion.getValue() instanceof java.util.List)
                        || ((java.util.List<?>) criterion.getValue()).isEmpty())) {
                    throw new IllegalArgumentException("锁定查询的集合条件不能为空");
                }
                valid = true;
            }
        }
        if (!valid) { throw new IllegalArgumentException("锁定查询禁止无条件整表查询"); }
        return true;
    }
}