package com.vgosoft.sensitive.controller;

import com.vgosoft.sensitive.codegen.controller.AbstractSensitiveWordController;
import com.vgosoft.sensitive.pojo.maps.SensitiveWordMappings;
import com.vgosoft.sensitive.service.ISensitiveWord;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = {"sensitive/sensitive-word-impl"})
public class SensitiveWordController extends AbstractSensitiveWordController {
    public SensitiveWordController(ISensitiveWord sensitiveWordImpl, SensitiveWordMappings mappings) {
        super(sensitiveWordImpl, mappings);
    }
}