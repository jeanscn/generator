package com.vgosoft.sensitive.pojo.vo;

import com.vgosoft.core.pojo.IBaseDTO;
import java.io.Serial;
import lombok.*;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SensitiveWordExcelImportVo implements IBaseDTO {
    @Serial
    private static final long serialVersionUID = 1L;

    private String word;

    private String categoryId;

    private String strategy;

    private Integer state;

    private String notes;

    {
        this.state = 1;
    }
}