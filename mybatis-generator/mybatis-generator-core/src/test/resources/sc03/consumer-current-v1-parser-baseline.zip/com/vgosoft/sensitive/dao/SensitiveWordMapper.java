package com.vgosoft.sensitive.dao;

import com.vgosoft.core.constant.enums.core.QueryModesEnum;
import com.vgosoft.mybatisplus.annotation.TableDataScope;
import com.vgosoft.sensitive.codegen.dao.GenSensitiveWordMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
@TableDataScope(dataScopeType = 20, tableAlias = "sw", columnName = "delete_flag", queryMode = QueryModesEnum.NOTEQUAL, columnValue = "1")
public interface SensitiveWordMapper extends GenSensitiveWordMapper {
}