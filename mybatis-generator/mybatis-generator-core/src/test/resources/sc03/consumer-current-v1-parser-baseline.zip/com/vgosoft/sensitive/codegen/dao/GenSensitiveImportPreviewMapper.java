package com.vgosoft.sensitive.codegen.dao;

import com.baomidou.mybatisplus.core.mapper.Mapper;
import com.vgosoft.mybatis.inf.MBGMapperInterface;
import com.vgosoft.sensitive.entity.SensitiveImportPreview;
import com.vgosoft.sensitive.entity.SensitiveImportPreviewExample;
import java.util.List;

public interface GenSensitiveImportPreviewMapper extends MBGMapperInterface<SensitiveImportPreview, SensitiveImportPreviewExample>, Mapper<SensitiveImportPreview> {
    int insertBatch(List<SensitiveImportPreview> sensitiveImportPreviews);

    int insertOrUpdate(SensitiveImportPreview sensitiveImportPreview);

    int updateBatchByPrimaryKey(List<SensitiveImportPreview> sensitiveImportPreviews);
}