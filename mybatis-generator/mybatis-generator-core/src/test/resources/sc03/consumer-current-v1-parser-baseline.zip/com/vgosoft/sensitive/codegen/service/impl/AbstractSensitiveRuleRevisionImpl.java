package com.vgosoft.sensitive.codegen.service.impl;

import com.vgosoft.core.adapter.ServiceResult;
import com.vgosoft.core.constant.enums.core.ServiceCodeEnum;
import com.vgosoft.core.exception.VgoException;
import com.vgosoft.mybatis.abs.AbstractMybatisBGService;
import com.vgosoft.sensitive.codegen.service.IGenSensitiveRuleRevision;
import com.vgosoft.sensitive.dao.SensitiveRuleRevisionMapper;
import com.vgosoft.sensitive.entity.SensitiveRuleRevision;
import com.vgosoft.sensitive.entity.SensitiveRuleRevisionExample;
import com.vgosoft.tool.core.VStringUtil;
import jakarta.annotation.Nullable;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public abstract class AbstractSensitiveRuleRevisionImpl extends AbstractMybatisBGService<SensitiveRuleRevisionMapper, SensitiveRuleRevision, SensitiveRuleRevisionExample> implements IGenSensitiveRuleRevision {
    private final SensitiveRuleRevisionMapper mapper;

    public AbstractSensitiveRuleRevisionImpl(SensitiveRuleRevisionMapper mapper) {
        super(mapper);
        this.mapper = mapper;
    }

    @Override
    public ServiceResult<List<SensitiveRuleRevision>> updateBatchByPrimaryKey(List<SensitiveRuleRevision> sensitiveRuleRevisions) {
        try {
            int i = mapper.updateBatchByPrimaryKey(sensitiveRuleRevisions);
            return ServiceResult.success(sensitiveRuleRevisions, i);
        } catch (Exception e) {
            throw new VgoException(ServiceCodeEnum.FAIL.code(), e.getMessage());
        }
    }

    @Override
    public int incrementRevisionByPrimaryKey(String id) {
        return mapper.incrementRevisionByPrimaryKey(id);
    }

    @Override
    public List<SensitiveRuleRevision> selectByPrimaryKeys(@Nullable String ids) {
        if (!VStringUtil.stringHasValue(ids)) {
            return this.selectByExample(new SensitiveRuleRevisionExample()).getResult();
        } else {
            return Arrays.stream(ids.split(","))
                    .map(this::selectByPrimaryKey)
                    .filter(ServiceResult::hasResult)
                    .map(ServiceResult::getResult)
                    .collect(Collectors.toList());
        }
    }
}