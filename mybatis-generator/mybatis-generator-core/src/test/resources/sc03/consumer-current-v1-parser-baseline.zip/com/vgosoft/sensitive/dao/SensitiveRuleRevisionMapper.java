package com.vgosoft.sensitive.dao;

import com.vgosoft.sensitive.codegen.dao.GenSensitiveRuleRevisionMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SensitiveRuleRevisionMapper extends GenSensitiveRuleRevisionMapper {
}