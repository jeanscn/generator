package com.vgosoft.sensitive.codegen.controller;

import static com.vgosoft.core.adapter.web.respone.ResponseResult.*;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.vgosoft.core.adapter.ServiceResult;
import com.vgosoft.core.adapter.web.FilterParam;
import com.vgosoft.core.adapter.web.respone.ResponseResult;
import com.vgosoft.core.annotation.SystemLog;
import com.vgosoft.core.constant.SymbolConstants;
import com.vgosoft.core.constant.enums.core.ApiCodeEnum;
import com.vgosoft.core.constant.enums.db.DefaultColumnNameEnum;
import com.vgosoft.core.constant.enums.view.HtmlDocumentTypeEnum;
import com.vgosoft.core.valid.ValidateInsert;
import com.vgosoft.core.valid.ValidateQuery;
import com.vgosoft.core.valid.ValidateUpdate;
import com.vgosoft.mybatis.pojo.ResponsePagehelperResult;
import com.vgosoft.mybatis.sqlbuilder.SelectSqlBuilder;
import com.vgosoft.plugins.excel.listener.DefaultColumnWidthStyleStrategy;
import com.vgosoft.plugins.excel.listener.DefaultReadListener;
import com.vgosoft.plugins.excel.pojo.vo.VgoExcelImportConfirmVo;
import com.vgosoft.plugins.excel.pojo.vo.VgoExcelImportPreviewVo;
import com.vgosoft.plugins.excel.pojo.vo.VgoExcelImportResultVo;
import com.vgosoft.plugins.excel.service.VgoFesodSheet;
import com.vgosoft.sensitive.entity.SensitiveWord;
import com.vgosoft.sensitive.entity.SensitiveWordExample.Criteria;
import com.vgosoft.sensitive.entity.SensitiveWordExample;
import com.vgosoft.sensitive.pojo.maps.SensitiveWordMappings;
import com.vgosoft.sensitive.pojo.vo.SensitiveWordCreateVo;
import com.vgosoft.sensitive.pojo.vo.SensitiveWordExcelImportVo;
import com.vgosoft.sensitive.pojo.vo.SensitiveWordRequestVo;
import com.vgosoft.sensitive.pojo.vo.SensitiveWordUpdateVo;
import com.vgosoft.sensitive.pojo.vo.SensitiveWordVo;
import com.vgosoft.sensitive.service.ISensitiveWord;
import com.vgosoft.tool.ValidList;
import com.vgosoft.tool.core.JsonUtil;
import com.vgosoft.tool.core.VReflectionUtil;
import com.vgosoft.tool.core.VStringUtil;
import com.vgosoft.web.controller.abs.AbstractBaseController;
import com.vgosoft.web.plugins.datatables.DataTablesConfig;
import com.vgosoft.web.plugins.datatables.DataTablesMappings;
import com.vgosoft.web.plugins.datatables.util.DataTablesUtil;
import com.vgosoft.web.pojo.ControllerViewParam;
import com.vgosoft.web.pojo.vo.ViewDtTableVo;
import com.vgosoft.web.utils.ParameterUtil;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.annotation.security.PermitAll;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.apache.fesod.sheet.write.handler.CellWriteHandler;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.util.Assert;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

public abstract class AbstractSensitiveWordController extends AbstractBaseController<SensitiveWord, SensitiveWordVo> {
    private final ISensitiveWord sensitiveWordImpl;

    private final SensitiveWordMappings mappings;

    public AbstractSensitiveWordController(ISensitiveWord sensitiveWordImpl, SensitiveWordMappings mappings) {
        this.sensitiveWordImpl = sensitiveWordImpl;
        this.mappings = mappings;
    }

    @PermitAll
    @SystemLog(value = "敏感词管理:通过表单查看或创建记录")
    @GetMapping(value = {"view"})
    @Operation(summary = "获得数据并返回页面视图（可用于普通业务在列表中新建接口）", description = "根据给定id获取单个实体，id为可选参数，当id存在时查询数据，否则直接返回视图")
    protected ModelAndView viewSensitiveWord(ControllerViewParam viewParam, HttpServletResponse response) throws Exception {
        response.addHeader("X-Frame-Options", "SAMEORIGIN");
        ModelAndView mv = new ModelAndView();
        String viewName = null;
        SensitiveWordVo sensitiveWordVo;
        if (viewParam.getId() != null) {
            ServiceResult<SensitiveWord> serviceResult = sensitiveWordImpl.selectByPrimaryKey(viewParam.getId());
            if (serviceResult.hasResult()) {
                SensitiveWord sensitiveWord = serviceResult.getResult();
                if (!VStringUtil.stringHasValue(viewParam.getPrefix()) || HtmlDocumentTypeEnum.EDITABLE.prefix().equals(viewParam.getPrefix())) {
                    viewName = "sensitive/sensitive_word";
                    mv.addObject("viewStatus", Optional.ofNullable(viewParam.getViewStatus()).orElse("1"));
                    mv.addObject("htmlFileName", "sensitive_word.html");
                }
                sensitiveWordVo = mappings.toSensitiveWordVo(serviceResult.getResult());
            } else {
                mv.addObject("error", serviceResult.getMessage());
                viewName = "sensitive/sensitive_word";
                mv.addObject("htmlFileName", "sensitive_word.html");
                sensitiveWordVo = updateNewInstanceDefaultValue(new SensitiveWordVo());
            }
        } else {
            sensitiveWordVo = updateNewInstanceDefaultValue(new SensitiveWordVo());
        }
        if (sensitiveWordVo != null) {
            SensitiveWordVo sensitiveWordView = JsonUtil.serializeObject(sensitiveWordVo);
            if (viewParam.getRValue() != null && viewParam.getRField() != null) {
                VReflectionUtil.writeField(sensitiveWordView, viewParam.getRField(), viewParam.getRValue());
            }
            mv.addObject("entity", sensitiveWordView);
        }
        if (!VStringUtil.stringHasValue(viewName)) {
            viewName = "sensitive/sensitive_word";
            mv.addObject("htmlFileName", "sensitive_word.html");
        }
        mv.addAllObjects(getCurrentUserInfo());
        mv.setViewName(viewName);
        return mv;
    }

    @SystemLog(value = "敏感词管理:实例化空对象")
    @GetMapping(value = {"new-instance"})
    @Operation(summary = "实例化对象", description = "实例化一个空对象，供前端使用")
    protected ResponseResult<SensitiveWordVo> newInstanceSensitiveWord(SensitiveWordCreateVo sensitiveWordCreateVo) {
        SensitiveWord sensitiveWord = mappings.fromSensitiveWordCreateVo(sensitiveWordCreateVo);
        SensitiveWordVo object = mappings.toSensitiveWordVo(sensitiveWord);
        return ResponseResult.success(updateNewInstanceDefaultValue(object));
    }

    @SystemLog(value = "敏感词管理:根据主键查询单条")
    @GetMapping(value = {"{id}"})
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivewordimpl:get')")
    @Operation(summary = "获得单条记录", description = "根据给定id获取单个实体")
    protected ResponseResult<SensitiveWordVo> getSensitiveWord(@PathVariable String id) {
        ServiceResult<SensitiveWord> serviceResult = sensitiveWordImpl.selectByPrimaryKey(id);
        if (serviceResult.hasResult()) {
            return success(mappings.toSensitiveWordVo(serviceResult.getResult()));
        } else {
            return failure(ApiCodeEnum.FAIL_NOT_FOUND, "敏感词管理数据记录");
        }
    }

    @SystemLog(value = "敏感词管理:查看数据列表")
    @GetMapping()
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivewordimpl:list')")
    @Operation(summary = "获得列表数据", description = "根据给定条件获取多条或所有数据列表，可以根据需要传入属性同名参数")
    protected ResponseResult<List<SensitiveWordVo>> listSensitiveWord(@Validated(value= ValidateQuery.class) SensitiveWordRequestVo sensitiveWordRequestVo, @RequestParam(required = false) String actionType) {
        if (actionType != null) {sensitiveWordRequestVo.setActionType(actionType);}
        SensitiveWordExample example = buildExample(sensitiveWordRequestVo);
        ServiceResult<List<SensitiveWord>> result;
        Page<SensitiveWord> page = null;
        if (sensitiveWordRequestVo.getPageNo() == 0 || sensitiveWordRequestVo.getPageSize() == 0) {
            PageHelper.clearPage();
            result = sensitiveWordImpl.selectByExample(example);
        } else {
            PageHelper.startPage(sensitiveWordRequestVo.getPageNo(), sensitiveWordRequestVo.getPageSize());
            result = sensitiveWordImpl.selectByExample(example);
            page = (Page<SensitiveWord>) result.getResult();
        }
        if (result.hasResult()) {
            if (page != null) {
                return ResponsePagehelperResult.success(mappings.toSensitiveWordVos(result.getResult()), page);
            } else {
                return ResponseResult.success(mappings.toSensitiveWordVos(result.getResult()));
            }
        } else {
            return ResponseResult.success(new ArrayList<>());
        }
    }

    @SystemLog(value = "敏感词管理:查看数据列表")
    @PostMapping(value = {"list"})
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivewordimpl:list')")
    @Operation(summary = "获得列表数据", description = "根据给定条件获取多条或所有数据列表，可以根据需要传入属性同名参数")
    protected ResponseResult<List<SensitiveWordVo>> listPostSensitiveWord(@RequestBody SensitiveWordRequestVo sensitiveWordRequestVo, @RequestParam(required = false) String actionType) {
        if (actionType != null) {sensitiveWordRequestVo.setActionType(actionType);}
        SensitiveWordExample example = buildExample(sensitiveWordRequestVo);
         FilterParam filterParam = sensitiveWordRequestVo.getFilterParam();
         if (filterParam != null) {
            String filterSql = ParameterUtil.parseFilterMap(filterParam, "sw");
            if (VStringUtil.stringHasValue(filterSql)) {
                 example.getOredCriteria().forEach(criteria -> criteria.andAnyCondition(filterSql));
            }
        }
        ServiceResult<List<SensitiveWord>> result;
        Page<SensitiveWord> page = null;
        if (sensitiveWordRequestVo.getPageNo() == 0 || sensitiveWordRequestVo.getPageSize() == 0) {
            PageHelper.clearPage();
            result = sensitiveWordImpl.selectByExample(example);
        } else {
            PageHelper.startPage(sensitiveWordRequestVo.getPageNo(), sensitiveWordRequestVo.getPageSize());
            result = sensitiveWordImpl.selectByExample(example);
            page = (Page<SensitiveWord>) result.getResult();
        }
        if (result.hasResult()) {
            if (page != null) {
                return ResponsePagehelperResult.success(mappings.toSensitiveWordVos(result.getResult()), page);
            } else {
                return ResponseResult.success(mappings.toSensitiveWordVos(result.getResult()));
            }
        } else {
            return ResponseResult.success(new ArrayList<>());
        }
    }

    @SystemLog(value = "敏感词管理:添加了一条记录")
    @PostMapping()
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivewordimpl:create')")
    @Operation(summary = "新增一条记录", description = "新增一条记录,返回json，包含影响条数及消息")
    protected ResponseResult<SensitiveWordVo> createSensitiveWord(@Validated(value= ValidateInsert.class) @RequestBody SensitiveWordCreateVo sensitiveWordCreateVo) {
        ServiceResult<SensitiveWord> serviceResult;
        if (sensitiveWordCreateVo.isSelectiveUpdate() && VStringUtil.isNotBlank(sensitiveWordCreateVo.getId())) {
            serviceResult = sensitiveWordImpl.updateByPrimaryKeySelective(mappings.fromSensitiveWordCreateVo(sensitiveWordCreateVo));
        } else if (sensitiveWordCreateVo.isSelectiveUpdate()) {
            serviceResult = sensitiveWordImpl.insertSelective(mappings.fromSensitiveWordCreateVo(sensitiveWordCreateVo));
        } else if (VStringUtil.isNotBlank(sensitiveWordCreateVo.getId())) {
            serviceResult = sensitiveWordImpl.updateByPrimaryKey(mappings.fromSensitiveWordCreateVo(sensitiveWordCreateVo));
        } else {
            serviceResult = sensitiveWordImpl.insert(mappings.fromSensitiveWordCreateVo(sensitiveWordCreateVo));
        }
        if (!serviceResult.isSuccess()) {
            serviceResult = sensitiveWordImpl.insertOrUpdate(mappings.fromSensitiveWordCreateVo(sensitiveWordCreateVo));
        }
        if (serviceResult.hasResult()) {
            return success(mappings.toSensitiveWordVo(serviceResult.getResult()),serviceResult.getAffectedRows());
        }else{
            return failure(ApiCodeEnum.FAIL_CUSTOM,serviceResult.getMessage());
        }
    }

    @SystemLog(value = "敏感词管理:添加了多条记录")
    @PostMapping(value = {"batch"})
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivewordimpl:createbatch')")
    @Operation(summary = "新增多条记录", description = "新增多条记录,返回影响条数及消息")
    protected ResponseResult<List<SensitiveWordVo>> createBatchSensitiveWord(@Validated(value= ValidateInsert.class) @RequestBody ValidList<SensitiveWordCreateVo> sensitiveWordCreateVos) {
        ServiceResult<List<SensitiveWord>> serviceResult = sensitiveWordImpl.insertBatch(mappings.fromSensitiveWordCreateVos(sensitiveWordCreateVos));
        if (serviceResult.hasResult()) {
            return success(mappings.toSensitiveWordVos(serviceResult.getResult()),serviceResult.getAffectedRows());
        }else{
            return failure(ApiCodeEnum.FAIL_CUSTOM,serviceResult.getMessage());
        }
    }

    @SystemLog(value = "敏感词管理:更新了一条记录")
    @PutMapping()
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivewordimpl:update')")
    @Operation(summary = "更新一条记录", description = "根据主键更新数据")
    protected ResponseResult<SensitiveWordVo> updateSensitiveWord(@Validated(value= ValidateUpdate.class) @RequestBody SensitiveWordUpdateVo sensitiveWordUpdateVo) {
        ServiceResult<SensitiveWord> serviceResult = sensitiveWordImpl.updateByPrimaryKeySelective(mappings.fromSensitiveWordUpdateVo(sensitiveWordUpdateVo));
        if (serviceResult.hasResult()) {
            return success(mappings.toSensitiveWordVo(serviceResult.getResult()),serviceResult.getAffectedRows());
        }else{
            return failure(ApiCodeEnum.FAIL_CUSTOM,serviceResult.getMessage());
        }
    }

    @SystemLog(value = "敏感词管理:更新了多条记录")
    @PutMapping(value = {"batch"})
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivewordimpl:updatebatch')")
    @Operation(summary = "批量更新数据", description = "根据主键批量更新数据")
    protected ResponseResult<List<SensitiveWordVo>> updateBatchSensitiveWord(@Validated(value= ValidateUpdate.class) @RequestBody ValidList<SensitiveWordUpdateVo> sensitiveWordUpdateVos) {
        ServiceResult<List<SensitiveWord>> result =  sensitiveWordImpl.updateBatchByPrimaryKey(mappings.fromSensitiveWordUpdateVos(sensitiveWordUpdateVos));
        if (result.hasResult()) {
            return success(mappings.toSensitiveWordVos(result.getResult()),result.getAffectedRows());
        }else{
            return failure(ApiCodeEnum.FAIL_CUSTOM,result.getMessage());
        }
    }

    @SystemLog(value = "敏感词管理:删除了一条记录")
    @DeleteMapping(value = {"{id}"})
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivewordimpl:delete')")
    @Operation(summary = "单条记录删除", description = "根据给定的id删除一条记录")
    protected ResponseResult<Long> deleteSensitiveWord(@PathVariable String id) {
        ServiceResult<Integer> result =  sensitiveWordImpl.deleteByPrimaryKey(id);
        if (result.hasResult() && result.getResult() > 0) {
            return success((long) result.getResult(),result.getAffectedRows());
        } else {
            return failure(ApiCodeEnum.FAIL_CUSTOM,result.getMessage());
        }
    }

    @SystemLog(value = "敏感词管理:删除了一条或多条记录")
    @DeleteMapping()
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivewordimpl:deletebatch')")
    @Operation(summary = "批量记录删除", description = "根据给定的一组id删除多条记录")
    protected ResponseResult<Long> deleteBatchSensitiveWord(@RequestBody List<String> ids) {
        SensitiveWordExample example = new SensitiveWordExample();
        example.createCriteria().andIdIn(ids);
        ServiceResult<Integer> result =  sensitiveWordImpl.deleteByExample(example);
        if (result.hasResult() && result.getResult() > 0) {
            return success((long) result.getResult(),result.getAffectedRows());
        } else {
            return failure(ApiCodeEnum.FAIL_CUSTOM,result.getMessage());
        }
    }

    @SystemLog(value = "敏感词管理:查看表默认视图配置")
    @PostMapping(value = {"dt/view-default"})
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivewordimpl:getdefaultviewconfig')")
    @Operation(summary = "默认数据视图配置", description = "获取默认数据视图配置")
    protected ResponseResult<DataTablesConfig> getDefaultViewConfigSensitiveWord() {
        Optional<ViewDtTableVo> result = DataTablesUtil
                .getSingleViewDtTableByAnnotation(DataTablesUtil.getDefaultViewId("sensitiveWordImpl"), true);
        return result.map(viewDtTableVo -> success(DataTablesMappings.INSTANCE.fromViewDtTableVo(viewDtTableVo)))
                .orElseGet(() -> failure(ApiCodeEnum.FAIL_NOT_FOUND,"默认列表配置"));
    }

    @SystemLog(value = "敏感词管理:查看默认视图")
    @GetMapping(value = {"dt/view-default/show"})
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivewordimpl:getdefaultview')")
    @Operation(summary = "默认数据视图显示", description = "显示默认数据视图")
    protected ModelAndView getDefaultViewSensitiveWord() {
        ModelAndView modelAndView = new ModelAndView("vgoweb/view/DataTables");
        modelAndView.addObject("viewId", DataTablesUtil.getDefaultViewId("sensitiveWordImpl"));
        modelAndView.addObject("listName", "敏感词管理");
        return modelAndView;
    }

    @SystemLog(value = "敏感词管理:下载数据导入模板")
    @GetMapping(value = {"import/template"}, produces = {MediaType.APPLICATION_OCTET_STREAM_VALUE})
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivewordimpl:template')")
    @Operation(summary = "Excel导入模板", description = "下载Excel导入模板接口")
    protected void templateSensitiveWord(HttpServletResponse response) throws IOException {
        List<SensitiveWordExcelImportVo> list = buildTemplateSampleData();
        VgoFesodSheet.writeTemplate(response, "敏感词管理导入模板", "敏感词管理", SensitiveWordExcelImportVo.class, list, List.of(new VgoFesodSheet.TemplateColumn("word", "敏感词（待匹配词面，应用上限为256个UTF-16单元）", List.of()), new VgoFesodSheet.TemplateColumn("categoryId", "所属分类（关联敏感词分类标识，空值表示未分类，不建物理外键）", List.of()), new VgoFesodSheet.TemplateColumn("strategy", "留空表示继承全局策略；选择阻断、确认后放行、替换后保存或告警放行策略。", List.of("BLOCK", "CONFIRM", "REPLACE", "WARN")), new VgoFesodSheet.TemplateColumn("state", "启用状态（1：启用，0：停用）", List.of("1", "0")), new VgoFesodSheet.TemplateColumn("notes", "备注", List.of())), getDefaultColumnWidthStyleStrategy("template"));
    }

    @SystemLog(value = "敏感词管理:Excel 导入预览")
    @PostMapping(value = {"import/preview"}, consumes = {MediaType.MULTIPART_FORM_DATA_VALUE}, produces = {MediaType.APPLICATION_JSON_VALUE})
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivewordimpl:import')")
    @Operation(summary = "Excel 导入预览", description = "解析并校验 Excel 导入内容")
    protected ResponseResult<VgoExcelImportPreviewVo<SensitiveWordExcelImportVo>> importPreviewSensitiveWord(@RequestPart("file") MultipartFile file) throws IOException {
        if (file == null || file.isEmpty()) {
            return ResponseResult.failure(ApiCodeEnum.FAIL_VALIDATION, "请选择有效的 Excel 文件");
        }
        VgoExcelImportPreviewVo<SensitiveWordExcelImportVo> preview = sensitiveWordImpl.previewExcelImport(file);
        if (preview == null) {
            return ResponseResult.failure(ApiCodeEnum.FAIL_VALIDATION, "Excel 导入预览未返回结果");
        }
        return ResponseResult.success(preview);
    }

    @SystemLog(value = "敏感词管理:Excel 导入确认")
    @PostMapping(value = {"import/confirm"}, consumes = {MediaType.MULTIPART_FORM_DATA_VALUE}, produces = {MediaType.APPLICATION_JSON_VALUE})
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivewordimpl:import')")
    @Operation(summary = "Excel 导入确认", description = "重新解析文件并提交已校验的 Excel 导入预览")
    protected ResponseResult<VgoExcelImportResultVo> importConfirmSensitiveWord(@RequestPart("file") MultipartFile file, @Valid @RequestPart("request") VgoExcelImportConfirmVo request) throws IOException {
        if (file == null || file.isEmpty()) {
            return ResponseResult.failure(ApiCodeEnum.FAIL_VALIDATION, "请选择有效的 Excel 文件");
        }
        VgoFesodSheet.BoundedReadResult<SensitiveWordExcelImportVo> parsed = VgoFesodSheet.readBounded(
                file, SensitiveWordExcelImportVo.class, new DefaultReadListener<>(),
                new VgoFesodSheet.ImportReadLimits(31457280L, 62914560L, 31457280L, 256, 100, 100));
        VgoExcelImportResultVo result = sensitiveWordImpl.confirmExcelImport(request, parsed.rows(), parsed.fileSha256());
        if (result == null || result.getImportedRows() < 0) {
            return ResponseResult.failure(ApiCodeEnum.FAIL_VALIDATION, "Excel 导入确认未返回有效结果");
        }
        return ResponseResult.success(result);
    }

    @GetMapping(value = {"select-by-column-id-and-version"})
    @Operation(summary = "根据指定列获取匹配的记录集合", description = "根据指定列获取匹配的记录集合接口")
    protected ResponseResult<List<SensitiveWordVo>> selectByColumnIdAndVersionSensitiveWord(@RequestParam(value = "id") String id, @RequestParam(value = "version") Integer version) {
        Assert.notNull(id, "参数id非法！");
        Assert.notNull(version, "参数version非法！");
        List<SensitiveWord> sensitiveWords = sensitiveWordImpl.selectByColumnIdAndVersion(id, version);
        if (!sensitiveWords.isEmpty()) {
            List<SensitiveWordVo> sensitiveWordVos = mappings.toSensitiveWordVos(sensitiveWords);
            return ResponseResult.success(sensitiveWordVos);
        } else {
            return ResponseResult.failure(ApiCodeEnum.NOT_FOUND, "未找到对应的记录");
        }
    }

    @PostMapping(value = {"delete-by-column-id-and-version"})
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivewordimpl:delete')")
    @SystemLog(value = "敏感词管理:按条件逻辑删除记录")
    @Operation(summary = "按指定条件逻辑删除", description = "按指定条件逻辑删除，版本表须传入客户端旧版本")
    protected ResponseResult<Integer> deleteByColumnIdAndVersionSensitiveWord(@RequestParam(value = "id") String id, @RequestParam(value = "version") Integer version) {
        return ResponseResult.success(sensitiveWordImpl.deleteByColumnIdAndVersion(id, version));
    }

    @PostMapping(value = {"select-by-column-ids"})
    @Operation(summary = "根据指定列（多值）获取匹配的记录集合", description = "根据指定列（多值）获取匹配的记录集合接口")
    protected ResponseResult<List<SensitiveWordVo>> selectByColumnIdsSensitiveWord(@RequestBody Map<String, List<String>> paramsMap) {
        List<String> ids = paramsMap.get("ids");
         if (ids.isEmpty()) {
            return ResponseResult.failure(ApiCodeEnum.FAIL_CUSTOM, "id列表不能为空");
        }
        List<SensitiveWord> sensitiveWords = sensitiveWordImpl.selectByColumnIds(ids);
        if (!sensitiveWords.isEmpty()) {
            List<SensitiveWordVo> sensitiveWordVos = mappings.toSensitiveWordVos(sensitiveWords);
            return ResponseResult.success(sensitiveWordVos);
        } else {
            return ResponseResult.failure(ApiCodeEnum.NOT_FOUND, "未找到对应的记录");
        }
    }

    @Override
    protected Page<SensitiveWord> getListData(String beanName, SelectSqlBuilder selectSqlBuilder, List<SensitiveWordVo> returnResult) {
        ServiceResult<List<SensitiveWord>> result = sensitiveWordImpl.selectBySql(selectSqlBuilder);
        if (result.hasResult()) {
            returnResult.addAll(mappings.toSensitiveWordVos(result.getResult()));
        }else{
            returnResult.addAll(new ArrayList<>());
        }
        return (Page<SensitiveWord>) result.getResult();
    }

    protected CellWriteHandler getDefaultColumnWidthStyleStrategy(String type) {
        return new DefaultColumnWidthStyleStrategy();
    }

    protected List<SensitiveWordExcelImportVo> buildTemplateSampleData() {
        return  List.of(
                SensitiveWordExcelImportVo.builder()
                        .word("word")
                        .categoryId("categoryId")
                        .strategy("strategy")
                        .state(0)
                        .notes("notes")
                        .build());
    }

    protected SensitiveWordExample buildExample(SensitiveWordRequestVo sensitiveWordRequestVo) {
        SensitiveWordExample example = new SensitiveWordExample();
        SensitiveWordExample.Criteria criteria = example.createCriteria();
        if (sensitiveWordRequestVo.isIgnoreDeleteFlag()) {example.setIgnoreDeleteFlag(true);}
        if (sensitiveWordRequestVo.isIgnorePermissionAnnotation()) {example.setIgnorePermissionAnnotation(true);}
        if (!VStringUtil.isBlank(sensitiveWordRequestVo.getId())) {
            if (VStringUtil.indexOf(sensitiveWordRequestVo.getId(), SymbolConstants.COMMA.charAt(0)) > -1) {
                criteria.andIdAnyCondition("regexp '(^|,)(" + sensitiveWordRequestVo.getId().replace(SymbolConstants.COMMA, SymbolConstants.PIPE) + ")(,|$)'" );
            }else{
                criteria.andIdEqualTo(sensitiveWordRequestVo.getId());
            }
        }
        if (sensitiveWordRequestVo.getVersion() != null) {
            criteria.andVersionEqualTo(sensitiveWordRequestVo.getVersion());
        }
        if (sensitiveWordRequestVo.getState() != null) {
            criteria.andStateEqualTo(sensitiveWordRequestVo.getState());
        }
        if (!VStringUtil.isBlank(sensitiveWordRequestVo.getWord())) {
            if (VStringUtil.indexOf(sensitiveWordRequestVo.getWord(), SymbolConstants.COMMA.charAt(0)) > -1) {
                criteria.andWordAnyCondition("regexp '(^|,)(" + sensitiveWordRequestVo.getWord().replace(SymbolConstants.COMMA, SymbolConstants.PIPE) + ")(,|$)'" );
            }else{
                criteria.andWordEqualTo(sensitiveWordRequestVo.getWord());
            }
        }
        if (!VStringUtil.isBlank(sensitiveWordRequestVo.getCategoryId())) {
            if (VStringUtil.indexOf(sensitiveWordRequestVo.getCategoryId(), SymbolConstants.COMMA.charAt(0)) > -1) {
                criteria.andCategoryIdAnyCondition("regexp '(^|,)(" + sensitiveWordRequestVo.getCategoryId().replace(SymbolConstants.COMMA, SymbolConstants.PIPE) + ")(,|$)'" );
            }else{
                criteria.andCategoryIdEqualTo(sensitiveWordRequestVo.getCategoryId());
            }
        }
        if (!VStringUtil.isBlank(sensitiveWordRequestVo.getStrategy())) {
            if (VStringUtil.indexOf(sensitiveWordRequestVo.getStrategy(), SymbolConstants.COMMA.charAt(0)) > -1) {
                criteria.andStrategyAnyCondition("regexp '(^|,)(" + sensitiveWordRequestVo.getStrategy().replace(SymbolConstants.COMMA, SymbolConstants.PIPE) + ")(,|$)'" );
            }else{
                criteria.andStrategyEqualTo(sensitiveWordRequestVo.getStrategy());
            }
        }
        if (!VStringUtil.isBlank(sensitiveWordRequestVo.getNotes())) {
            if (VStringUtil.indexOf(sensitiveWordRequestVo.getNotes(), SymbolConstants.COMMA.charAt(0)) > -1) {
                criteria.andNotesAnyCondition("regexp '(^|,)(" + sensitiveWordRequestVo.getNotes().replace(SymbolConstants.COMMA, SymbolConstants.PIPE) + ")(,|$)'" );
            }else{
                criteria.andNotesEqualTo(sensitiveWordRequestVo.getNotes());
            }
        }
        if (!VStringUtil.isBlank(sensitiveWordRequestVo.getAnyWhereCondition())) {
            criteria.andAnyCondition(sensitiveWordRequestVo.getAnyWhereCondition());
        }
        List<String> orderBy = new ArrayList<>();
        String orderByClause = sensitiveWordRequestVo.getOrderByClause();
        if (VStringUtil.stringHasValue(orderByClause)) {
            orderBy.add(orderByClause);
        } else {
            orderByClause = "";
        }
        if (!orderByClause.toLowerCase().contains(DefaultColumnNameEnum.CREATE_TIME.columnName())) {
            orderBy.add(DefaultColumnNameEnum.CREATE_TIME.columnName()+" desc");
        }
        if (!orderBy.isEmpty()) {
            example.setOrderByClause(String.join(SymbolConstants.COMMA, orderBy));
        }
        return example;
    }

    protected List<Criteria> getCriteriaList(SensitiveWordExample example) {
        List<SensitiveWordExample.Criteria> criteriaList = new ArrayList<>(example.getOredCriteria());
        if (criteriaList.isEmpty()) {
            criteriaList.add(example.createCriteria());
        }
        return criteriaList;
    }
}