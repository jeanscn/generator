package com.vgosoft.sensitive.codegen.dao;

import com.baomidou.mybatisplus.core.mapper.Mapper;
import com.vgosoft.mybatis.inf.MBGMapperInterface;
import com.vgosoft.sensitive.entity.SensitiveConfirmation;
import com.vgosoft.sensitive.entity.SensitiveConfirmationExample;
import java.util.List;

public interface GenSensitiveConfirmationMapper extends MBGMapperInterface<SensitiveConfirmation, SensitiveConfirmationExample>, Mapper<SensitiveConfirmation> {
    int insertBatch(List<SensitiveConfirmation> sensitiveConfirmations);

    int insertOrUpdate(SensitiveConfirmation sensitiveConfirmation);

    int updateBatchByPrimaryKey(List<SensitiveConfirmation> sensitiveConfirmations);
}