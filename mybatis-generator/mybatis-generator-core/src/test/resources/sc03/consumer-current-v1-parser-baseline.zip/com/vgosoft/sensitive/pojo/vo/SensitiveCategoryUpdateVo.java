package com.vgosoft.sensitive.pojo.vo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.vgosoft.sensitive.pojo.abs.AbstractSensitiveCategoryVo;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serial;
import lombok.*;

@Data
@ToString(callSuper = true)
@Schema(name = "SensitiveCategoryUpdateVo", description = "敏感词分类管理", implementation = AbstractSensitiveCategoryVo.class)
public class SensitiveCategoryUpdateVo extends AbstractSensitiveCategoryVo {
    @Serial
    private static final long serialVersionUID = 1L;

    @Schema(description = "更新时选择性插入", example = "true")
    @TableField(exist = false)
    private boolean selectiveUpdate;
}