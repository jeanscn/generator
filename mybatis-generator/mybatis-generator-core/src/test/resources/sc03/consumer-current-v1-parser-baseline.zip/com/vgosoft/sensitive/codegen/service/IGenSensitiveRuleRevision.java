package com.vgosoft.sensitive.codegen.service;

import com.vgosoft.core.adapter.ServiceResult;
import com.vgosoft.mybatis.inf.IMybatisBGService;
import com.vgosoft.sensitive.entity.SensitiveRuleRevision;
import com.vgosoft.sensitive.entity.SensitiveRuleRevisionExample;
import jakarta.annotation.Nullable;
import java.util.List;

public interface IGenSensitiveRuleRevision extends IMybatisBGService<SensitiveRuleRevision, SensitiveRuleRevisionExample> {
    ServiceResult<List<SensitiveRuleRevision>> updateBatchByPrimaryKey(List<SensitiveRuleRevision> sensitiveRuleRevisions);

    int incrementRevisionByPrimaryKey(String id);

    List<SensitiveRuleRevision> selectByPrimaryKeys(@Nullable String ids);
}