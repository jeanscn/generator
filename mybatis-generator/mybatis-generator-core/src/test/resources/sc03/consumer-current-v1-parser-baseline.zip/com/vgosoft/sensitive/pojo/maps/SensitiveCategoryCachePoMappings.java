package com.vgosoft.sensitive.pojo.maps;

import com.vgosoft.sensitive.entity.SensitiveCategory;
import com.vgosoft.sensitive.pojo.po.SensitiveCategoryCachePo;
import com.vgosoft.sensitive.pojo.vo.SensitiveCategoryVo;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring",unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface SensitiveCategoryCachePoMappings {
    /** 
     * 将SensitiveCategory转换为SensitiveCategoryCachePo
     * @param sensitiveCategory 待转换的源对象
     * @return SensitiveCategoryCachePo 转换后的目标对象
     * 提示 - @VCF.generated
    */
    @Mapping(source = "name",target = "dictValueText")
    SensitiveCategoryCachePo toSensitiveCategoryCachePo(SensitiveCategory sensitiveCategory);

    /** 
     * 将SensitiveCategory转换为SensitiveCategoryCachePo
     * @param sensitiveCategorys 待转换的源对象
     * @return List<SensitiveCategoryCachePo> 转换后的目标对象集合
     * 提示 - @VCF.generated
    */
    List<SensitiveCategoryCachePo> toSensitiveCategoryCachePos(List<SensitiveCategory> sensitiveCategorys);

    /** 
     * 将SensitiveCategoryCachePo转换为SensitiveCategory
     * @param sensitiveCategoryCachePo 待转换的源对象
     * @return SensitiveCategory 转换后的目标对象
     * 提示 - @VCF.generated
    */
    SensitiveCategory fromSensitiveCategoryCachePo(SensitiveCategoryCachePo sensitiveCategoryCachePo);

    /** 
     * 将SensitiveCategoryCachePo转换为SensitiveCategory
     * @param sensitiveCategoryCachePos 待转换的源对象
     * @return List<SensitiveCategory> 转换后的目标对象集合
     * 提示 - @VCF.generated
    */
    List<SensitiveCategory> fromSensitiveCategoryCachePos(List<SensitiveCategoryCachePo> sensitiveCategoryCachePos);

    /** 
     * 将SensitiveCategoryCachePo转换为SensitiveCategoryVo
     * @param sensitiveCategoryCachePo 待转换的源对象
     * @return SensitiveCategoryVo 转换后的目标对象
     * 提示 - @VCF.generated
    */
    SensitiveCategoryVo fromSensitiveCategoryCachePoToSensitiveCategoryVo(SensitiveCategoryCachePo sensitiveCategoryCachePo);

    /** 
     * 将SensitiveCategoryCachePo转换为SensitiveCategoryVo
     * @param sensitiveCategoryCachePos 待转换的源对象
     * @return List<SensitiveCategoryVo> 转换后的目标对象集合
     * 提示 - @VCF.generated
    */
    List<SensitiveCategoryVo> fromSensitiveCategoryCachePoToSensitiveCategoryVos(List<SensitiveCategoryCachePo> sensitiveCategoryCachePos);
}