package com.vgosoft.sensitive.dao;

import com.vgosoft.sensitive.codegen.dao.GenSensitiveAuditOutboxMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SensitiveAuditOutboxMapper extends GenSensitiveAuditOutboxMapper {
}