package com.vgosoft.sensitive.codegen.service;

import com.vgosoft.core.adapter.ServiceResult;
import com.vgosoft.core.annotation.DictPrefetchProvider;
import com.vgosoft.mybatis.inf.IMybatisBGService;
import com.vgosoft.sensitive.entity.SensitiveCategory;
import com.vgosoft.sensitive.entity.SensitiveCategoryExample;
import com.vgosoft.sensitive.pojo.po.SensitiveCategoryCachePo;
import jakarta.annotation.Nullable;
import java.util.List;
import java.util.Optional;

public interface IGenSensitiveCategory extends IMybatisBGService<SensitiveCategory, SensitiveCategoryExample> {
    /**
     * 根据完整主键锁定并查询记录。
     * 必须在非只读既有事务中调用；锁持有至事务结束，数据库异常直接向外传播。
     * 不经过查询缓存；可见版本取决于数据库和事务隔离级别。
     * @param id 完整主键值
     * @return 锁定查询结果的服务包装
     * @throws IllegalStateException 未开启事务、只读事务或存在分页上下文
     * @throws IllegalArgumentException 查询条件不符合锁定查询约束
     */
    ServiceResult<SensitiveCategory> selectByPrimaryKeyForUpdate(String id);

    /**
     * 根据明确条件锁定并查询记录，禁止全表、去重、动态排序和分页。
     * 必须在非只读既有事务中调用；锁持有至事务结束，数据库异常直接向外传播。
     * 不经过查询缓存；可见版本取决于数据库和事务隔离级别。
     * @param example 非空白名单查询条件
     * @return 锁定查询结果的服务包装
     * @throws IllegalStateException 未开启事务、只读事务或存在分页上下文
     * @throws IllegalArgumentException 查询条件不符合锁定查询约束
     */
    ServiceResult<List<SensitiveCategory>> selectByExampleForUpdate(SensitiveCategoryExample example);

    ServiceResult<List<SensitiveCategory>> insertBatch(List<SensitiveCategory> sensitiveCategorys);

    ServiceResult<List<SensitiveCategory>> updateBatchByPrimaryKey(List<SensitiveCategory> sensitiveCategorys);

    Integer updateDeleteFlag(SensitiveCategory sensitiveCategory, int deleteFlag);

    ServiceResult<SensitiveCategory> insertOrUpdate(SensitiveCategory sensitiveCategory);

    List<SensitiveCategory> selectByColumnIdAndVersion(String id, Integer version);

    List<SensitiveCategory> selectByColumnIds(List<String> ids);

    int deleteByColumnIdAndVersion(String id, Integer version);

    List<SensitiveCategoryCachePo> selectByKeysDict(Optional<String> types, String keys);

    /**
     * 查询请求级字典预取所需的数据，不读取或写入 Spring 缓存。
     * @param types 可选字典类型
     * @param keys 逗号分隔的字典键
     * @return 按配置排序的缓存模型列表
     */
    @DictPrefetchProvider(keyProperty = "id", orderProperties = {"sort", "created", "id"}, uniqueOrderProperties = {"id"})
    List<SensitiveCategoryCachePo> selectByKeysDictForPrefetch(Optional<String> types, String keys);

    List<SensitiveCategory> selectByPrimaryKeys(@Nullable String ids);
}