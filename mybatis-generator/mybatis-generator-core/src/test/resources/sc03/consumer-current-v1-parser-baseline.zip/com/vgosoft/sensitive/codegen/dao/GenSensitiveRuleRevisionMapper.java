package com.vgosoft.sensitive.codegen.dao;

import com.baomidou.mybatisplus.core.mapper.Mapper;
import com.vgosoft.mybatis.inf.MBGMapperInterface;
import com.vgosoft.sensitive.entity.SensitiveRuleRevision;
import com.vgosoft.sensitive.entity.SensitiveRuleRevisionExample;
import java.util.List;

public interface GenSensitiveRuleRevisionMapper extends MBGMapperInterface<SensitiveRuleRevision, SensitiveRuleRevisionExample>, Mapper<SensitiveRuleRevision> {
    int updateBatchByPrimaryKey(List<SensitiveRuleRevision> sensitiveRuleRevisions);

    int incrementRevisionByPrimaryKey(String id);
}