package com.vgosoft.sensitive.pojo.vo;

import com.vgosoft.core.annotation.Dict;
import com.vgosoft.core.annotation.DictEnum;
import com.vgosoft.sensitive.pojo.abs.AbstractSensitiveWordVo;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serial;
import java.util.Date;
import lombok.*;

@Data
@ToString(callSuper = true)
@Schema(name = "SensitiveWordViewVo", description = "敏感词管理", implementation = AbstractSensitiveWordVo.class)
public class SensitiveWordViewVo extends AbstractSensitiveWordVo {
    @Serial
    private static final long serialVersionUID = 1L;

    private Integer deleteFlag;

    private Date created;

    private Date modified;

    private String createdId;

    private String modifiedId;

    @Dict(beanName = "sensitiveCategoryImpl", source = "categoryId")
    private String categoryText = "-";

    @DictEnum(value = "com.vgosoft.core.constant.enums.app.SensitiveWordStrategyEnum", source = "strategy")
    private String strategyText = "-";

    @DictEnum(value = "com.vgosoft.core.constant.enums.core.CommonStatusEnum", source = "state")
    private String stateText = "-";
}