package com.vgosoft.sensitive.service.impl;

import com.vgosoft.sensitive.codegen.service.impl.AbstractSensitiveWordImpl;
import com.vgosoft.sensitive.dao.SensitiveWordMapper;
import com.vgosoft.sensitive.service.ISensitiveWord;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

@Service("sensitiveWordImpl")
@Primary
public class SensitiveWordImpl extends AbstractSensitiveWordImpl implements ISensitiveWord {
    public SensitiveWordImpl(SensitiveWordMapper mapper) {
        super(mapper);
    }
}