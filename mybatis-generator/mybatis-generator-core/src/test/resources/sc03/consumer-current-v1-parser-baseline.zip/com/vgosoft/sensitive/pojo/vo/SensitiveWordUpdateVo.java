package com.vgosoft.sensitive.pojo.vo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.vgosoft.sensitive.pojo.abs.AbstractSensitiveWordVo;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serial;
import lombok.*;

@Data
@ToString(callSuper = true)
@Schema(name = "SensitiveWordUpdateVo", description = "敏感词管理", implementation = AbstractSensitiveWordVo.class)
public class SensitiveWordUpdateVo extends AbstractSensitiveWordVo {
    @Serial
    private static final long serialVersionUID = 1L;

    @Schema(description = "更新时选择性插入", example = "true")
    @TableField(exist = false)
    private boolean selectiveUpdate;
}