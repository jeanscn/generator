package com.vgosoft.sensitive.codegen.dao;

import com.baomidou.mybatisplus.core.mapper.Mapper;
import com.vgosoft.mybatis.inf.MBGMapperInterface;
import com.vgosoft.sensitive.entity.SensitiveHitLog;
import com.vgosoft.sensitive.entity.SensitiveHitLogExample;
import java.util.List;

public interface GenSensitiveHitLogMapper extends MBGMapperInterface<SensitiveHitLog, SensitiveHitLogExample>, Mapper<SensitiveHitLog> {
    int insertBatch(List<SensitiveHitLog> sensitiveHitLogs);
}