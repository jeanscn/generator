package com.vgosoft.sensitive.service;

import com.vgosoft.sensitive.codegen.service.IGenSensitiveCategory;

public interface ISensitiveCategory extends IGenSensitiveCategory {
}