package com.vgosoft.sensitive.service;

import com.vgosoft.sensitive.codegen.service.IGenSensitiveRuleRevision;

public interface ISensitiveRuleRevision extends IGenSensitiveRuleRevision {
}