package com.vgosoft.sensitive.codegen.dao;

import com.baomidou.mybatisplus.core.mapper.Mapper;
import com.vgosoft.mybatis.inf.MBGMapperInterface;
import com.vgosoft.sensitive.entity.SensitiveWord;
import com.vgosoft.sensitive.entity.SensitiveWordExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface GenSensitiveWordMapper extends MBGMapperInterface<SensitiveWord, SensitiveWordExample>, Mapper<SensitiveWord> {
    int insertBatch(List<SensitiveWord> sensitiveWords);

    int insertOrUpdate(SensitiveWord sensitiveWord);

    int updateBatchByPrimaryKey(List<SensitiveWord> sensitiveWords);

    /**
     * 根据完整主键锁定并查询记录。
     * 必须在非只读既有事务中调用；锁持有至事务结束，数据库异常直接向外传播。
     * 不经过查询缓存；可见版本取决于数据库和事务隔离级别。
     * @param id 完整主键值
     * @return 锁定查询的实体，不存在时为空
     * @throws IllegalStateException 未开启事务、只读事务或存在分页上下文
     * @throws IllegalArgumentException 查询条件不符合锁定查询约束
     */
    SensitiveWord selectByPrimaryKeyForUpdate(String id);

    /**
     * 根据明确条件锁定并查询记录，禁止全表、去重、动态排序和分页。
     * 必须在非只读既有事务中调用；锁持有至事务结束，数据库异常直接向外传播。
     * 不经过查询缓存；可见版本取决于数据库和事务隔离级别。
     * @param example 非空白名单查询条件
     * @return 锁定查询的实体列表
     * @throws IllegalStateException 未开启事务、只读事务或存在分页上下文
     * @throws IllegalArgumentException 查询条件不符合锁定查询约束
     */
    List<SensitiveWord> selectByExampleForUpdate(SensitiveWordExample example);

    List<SensitiveWord> selectByColumnIdAndVersion(@Param("id") String id, @Param("version") Integer version);

    List<SensitiveWord> selectByColumnIds(List<String> ids);

    int deleteByColumnIdAndVersion(@Param("id") String id, @Param("version") Integer version);
}