package com.vgosoft.sensitive.dao;

import com.vgosoft.sensitive.codegen.dao.GenSensitiveConfirmationMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface SensitiveConfirmationMapper extends GenSensitiveConfirmationMapper {
}