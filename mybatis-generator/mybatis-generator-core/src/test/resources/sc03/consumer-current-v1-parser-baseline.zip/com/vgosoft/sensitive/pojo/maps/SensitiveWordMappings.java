package com.vgosoft.sensitive.pojo.maps;

import com.vgosoft.sensitive.entity.SensitiveWord;
import com.vgosoft.sensitive.pojo.vo.SensitiveWordCreateVo;
import com.vgosoft.sensitive.pojo.vo.SensitiveWordExcelImportVo;
import com.vgosoft.sensitive.pojo.vo.SensitiveWordRequestVo;
import com.vgosoft.sensitive.pojo.vo.SensitiveWordUpdateVo;
import com.vgosoft.sensitive.pojo.vo.SensitiveWordViewVo;
import com.vgosoft.sensitive.pojo.vo.SensitiveWordVo;
import java.util.List;
import org.mapstruct.Mapper;
import org.mapstruct.ReportingPolicy;

@Mapper(componentModel = "spring",unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface SensitiveWordMappings {
    /** 
     * 将SensitiveWordVo转换为SensitiveWord
     * @param sensitiveWordVo 待转换的源对象
     * @return SensitiveWord 转换后的目标对象
     * 提示 - @VCF.generated
    */
    SensitiveWord fromSensitiveWordVo(SensitiveWordVo sensitiveWordVo);

    /** 
     * 将SensitiveWord转换为SensitiveWordVo
     * @param sensitiveWord 待转换的源对象
     * @return SensitiveWordVo 转换后的目标对象
     * 提示 - @VCF.generated
    */
    SensitiveWordVo toSensitiveWordVo(SensitiveWord sensitiveWord);

    /** 
     * 将SensitiveWordVo转换为SensitiveWord
     * @param sensitiveWordVos 待转换的源对象
     * @return List<SensitiveWord> 转换后的目标对象集合
     * 提示 - @VCF.generated
    */
    List<SensitiveWord> fromSensitiveWordVos(List<SensitiveWordVo> sensitiveWordVos);

    /** 
     * 将SensitiveWord转换为SensitiveWordVo
     * @param sensitiveWords 待转换的源对象
     * @return List<SensitiveWordVo> 转换后的目标对象集合
     * 提示 - @VCF.generated
    */
    List<SensitiveWordVo> toSensitiveWordVos(List<SensitiveWord> sensitiveWords);

    /** 
     * 将SensitiveWordCreateVo转换为SensitiveWord
     * @param sensitiveWordCreateVo 待转换的源对象
     * @return SensitiveWord 转换后的目标对象
     * 提示 - @VCF.generated
    */
    SensitiveWord fromSensitiveWordCreateVo(SensitiveWordCreateVo sensitiveWordCreateVo);

    /** 
     * 将SensitiveWordCreateVo转换为SensitiveWord
     * @param sensitiveWordCreateVos 待转换的源对象
     * @return List<SensitiveWord> 转换后的目标对象集合
     * 提示 - @VCF.generated
    */
    List<SensitiveWord> fromSensitiveWordCreateVos(List<SensitiveWordCreateVo> sensitiveWordCreateVos);

    /** 
     * 将SensitiveWordUpdateVo转换为SensitiveWord
     * @param sensitiveWordUpdateVo 待转换的源对象
     * @return SensitiveWord 转换后的目标对象
     * 提示 - @VCF.generated
    */
    SensitiveWord fromSensitiveWordUpdateVo(SensitiveWordUpdateVo sensitiveWordUpdateVo);

    /** 
     * 将SensitiveWordUpdateVo转换为SensitiveWord
     * @param sensitiveWordUpdateVos 待转换的源对象
     * @return List<SensitiveWord> 转换后的目标对象集合
     * 提示 - @VCF.generated
    */
    List<SensitiveWord> fromSensitiveWordUpdateVos(List<SensitiveWordUpdateVo> sensitiveWordUpdateVos);

    /** 
     * 将SensitiveWord转换为SensitiveWordViewVo
     * @param sensitiveWord 待转换的源对象
     * @return SensitiveWordViewVo 转换后的目标对象
     * 提示 - @VCF.generated
    */
    SensitiveWordViewVo toSensitiveWordViewVo(SensitiveWord sensitiveWord);

    /** 
     * 将SensitiveWord转换为SensitiveWordViewVo
     * @param sensitiveWords 待转换的源对象
     * @return List<SensitiveWordViewVo> 转换后的目标对象集合
     * 提示 - @VCF.generated
    */
    List<SensitiveWordViewVo> toSensitiveWordViewVos(List<SensitiveWord> sensitiveWords);

    /** 
     * 将SensitiveWord转换为SensitiveWordExcelImportVo
     * @param sensitiveWord 待转换的源对象
     * @return SensitiveWordExcelImportVo 转换后的目标对象
     * 提示 - @VCF.generated
    */
    SensitiveWordExcelImportVo toSensitiveWordExcelImportVo(SensitiveWord sensitiveWord);

    /** 
     * 将SensitiveWord转换为SensitiveWordExcelImportVo
     * @param sensitiveWords 待转换的源对象
     * @return List<SensitiveWordExcelImportVo> 转换后的目标对象集合
     * 提示 - @VCF.generated
    */
    List<SensitiveWordExcelImportVo> toSensitiveWordExcelImportVos(List<SensitiveWord> sensitiveWords);

    /** 
     * 将SensitiveWordExcelImportVo转换为SensitiveWord
     * @param sensitiveWordExcelImportVo 待转换的源对象
     * @return SensitiveWord 转换后的目标对象
     * 提示 - @VCF.generated
    */
    SensitiveWord fromSensitiveWordExcelImportVo(SensitiveWordExcelImportVo sensitiveWordExcelImportVo);

    /** 
     * 将SensitiveWordExcelImportVo转换为SensitiveWord
     * @param sensitiveWordExcelImportVos 待转换的源对象
     * @return List<SensitiveWord> 转换后的目标对象集合
     * 提示 - @VCF.generated
    */
    List<SensitiveWord> fromSensitiveWordExcelImportVos(List<SensitiveWordExcelImportVo> sensitiveWordExcelImportVos);

    /** 
     * 将SensitiveWordRequestVo转换为SensitiveWord
     * @param sensitiveWordRequestVo 待转换的源对象
     * @return SensitiveWord 转换后的目标对象
     * 提示 - @VCF.generated
    */
    SensitiveWord fromSensitiveWordRequestVo(SensitiveWordRequestVo sensitiveWordRequestVo);
}