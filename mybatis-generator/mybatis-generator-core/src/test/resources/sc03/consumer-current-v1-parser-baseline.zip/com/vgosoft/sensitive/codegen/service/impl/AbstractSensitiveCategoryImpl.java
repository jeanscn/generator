package com.vgosoft.sensitive.codegen.service.impl;

import static com.vgosoft.core.constant.CacheConstant.CACHE_MANAGER_NAME;

import com.vgosoft.core.adapter.ServiceResult;
import com.vgosoft.core.annotation.DictPrefetchProvider;
import com.vgosoft.core.constant.enums.core.ServiceCodeEnum;
import com.vgosoft.core.exception.VgoException;
import com.vgosoft.core.pojo.parameter.SelDictByKeysParam;
import com.vgosoft.mybatis.abs.AbstractMybatisBGService;
import com.vgosoft.mybatis.sqlbuilder.InsertSqlBuilder;
import com.vgosoft.mybatis.sqlbuilder.UpdateSqlBuilder;
import com.vgosoft.sensitive.codegen.service.IGenSensitiveCategory;
import com.vgosoft.sensitive.dao.SensitiveCategoryMapper;
import com.vgosoft.sensitive.entity.SensitiveCategory;
import com.vgosoft.sensitive.entity.SensitiveCategoryExample;
import com.vgosoft.sensitive.pojo.maps.SensitiveCategoryCachePoMappings;
import com.vgosoft.sensitive.pojo.po.SensitiveCategoryCachePo;
import com.vgosoft.tool.core.VStringUtil;
import jakarta.annotation.Nullable;
import jakarta.annotation.Resource;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import tools.jackson.databind.MapperFeature;
import tools.jackson.databind.SerializationFeature;
import tools.jackson.databind.json.JsonMapper;

@CacheConfig(cacheManager = CACHE_MANAGER_NAME)
public abstract class AbstractSensitiveCategoryImpl extends AbstractMybatisBGService<SensitiveCategoryMapper, SensitiveCategory, SensitiveCategoryExample> implements IGenSensitiveCategory {
    private final SensitiveCategoryMapper mapper;

    private static final JsonMapper VGOSOFT_CACHE_KEY_MAPPER = JsonMapper.builder().disable(SerializationFeature.INDENT_OUTPUT).enable(SerializationFeature.ORDER_MAP_ENTRIES_BY_KEYS).disable(MapperFeature.SORT_CREATOR_PROPERTIES_FIRST).enable(MapperFeature.SORT_PROPERTIES_ALPHABETICALLY).build();

    /**
     * 注入SensitiveCategoryCachePoMappings 实例
     */
    @Resource
    protected SensitiveCategoryCachePoMappings sensitiveCategoryCachePoMappingsImpl;

    public AbstractSensitiveCategoryImpl(SensitiveCategoryMapper mapper) {
        super(mapper);
        this.mapper = mapper;
    }

    @Override
    @CacheEvict(cacheNames = {"SensitiveCategory#8h"},allEntries = true)
    public ServiceResult<List<SensitiveCategory>> insertBatch(List<SensitiveCategory> sensitiveCategorys) {
        int i = mapper.insertBatch(sensitiveCategorys);
        if (i > 0) {
            return ServiceResult.success(sensitiveCategorys,i);
        }else{
            return ServiceResult.failure(ServiceCodeEnum.WARN);
        }
    }

    @Override
    @CacheEvict(cacheNames = {"SensitiveCategory#8h"},allEntries = true)
    public ServiceResult<List<SensitiveCategory>> updateBatchByPrimaryKey(List<SensitiveCategory> sensitiveCategorys) {
        try {
            int i = mapper.updateBatchByPrimaryKey(sensitiveCategorys);
            return ServiceResult.success(sensitiveCategorys, i);
        } catch (Exception e) {
            throw new VgoException(ServiceCodeEnum.FAIL.code(), e.getMessage());
        }
    }

    /**
     * 根据完整主键锁定并查询记录。
     * 必须在非只读既有事务中调用；锁持有至事务结束，数据库异常直接向外传播。
     * 不经过查询缓存；可见版本取决于数据库和事务隔离级别。
     * @param id 完整主键值
     * @return 锁定查询结果的服务包装
     * @throws IllegalStateException 未开启事务、只读事务或存在分页上下文
     * @throws IllegalArgumentException 查询条件不符合锁定查询约束
     */
    @Override
    @org.springframework.transaction.annotation.Transactional(propagation = org.springframework.transaction.annotation.Propagation.MANDATORY, rollbackFor = Exception.class)
    public ServiceResult<SensitiveCategory> selectByPrimaryKeyForUpdate(String id) {
        com.vgosoft.sensitive.codegen.dao.GenSensitiveCategoryMapperLockQueryGuard.requireSelectForUpdateTransaction();
        return ServiceResult.success(mapper.selectByPrimaryKeyForUpdate(id));
    }

    /**
     * 根据明确条件锁定并查询记录，禁止全表、去重、动态排序和分页。
     * 必须在非只读既有事务中调用；锁持有至事务结束，数据库异常直接向外传播。
     * 不经过查询缓存；可见版本取决于数据库和事务隔离级别。
     * @param example 非空白名单查询条件
     * @return 锁定查询结果的服务包装
     * @throws IllegalStateException 未开启事务、只读事务或存在分页上下文
     * @throws IllegalArgumentException 查询条件不符合锁定查询约束
     */
    @Override
    @org.springframework.transaction.annotation.Transactional(propagation = org.springframework.transaction.annotation.Propagation.MANDATORY, rollbackFor = Exception.class)
    public ServiceResult<List<SensitiveCategory>> selectByExampleForUpdate(SensitiveCategoryExample example) {
        com.vgosoft.sensitive.codegen.dao.GenSensitiveCategoryMapperLockQueryGuard.requireSelectForUpdateTransaction();
        com.vgosoft.sensitive.codegen.dao.GenSensitiveCategoryMapperLockQueryGuard.requireSelectForUpdateExample(example);
        return ServiceResult.success(mapper.selectByExampleForUpdate(example));
    }

    @Override
    @CacheEvict(cacheNames = {"SensitiveCategory#8h"},allEntries = true)
    public Integer updateDeleteFlag(SensitiveCategory sensitiveCategory, int deleteFlag) {
        sensitiveCategory.setDeleteFlag(deleteFlag);
        return mapper.updateByPrimaryKey(sensitiveCategory);
    }

    @CacheEvict(cacheNames = {"SensitiveCategory#8h"},allEntries = true)
    @Override
    public ServiceResult<SensitiveCategory> insertOrUpdate(SensitiveCategory sensitiveCategory) {
        try {
            int i = mapper.insertOrUpdate(sensitiveCategory);
            return ServiceResult.success(sensitiveCategory,i);
        } catch (Exception e) {
            throw new VgoException(ServiceCodeEnum.FAIL.code(), e.getMessage());
        }
    }

    public final String vgosoftCacheKeyJson(Object value) {
        return VGOSOFT_CACHE_KEY_MAPPER.writeValueAsString(value);
    }

    @Override
    @Cacheable(cacheNames = {"SensitiveCategory#8h"},unless = "#result==null || #result instanceof T(java.lang.Exception) || (#result instanceof T(java.util.Collection) && #result.isEmpty())",key = "#root.target.vgosoftCacheKeyJson({'vgosoft-cache-key-v3','SensitiveCategory','com.vgosoft.sensitive.entity.SensitiveCategory#selectByColumnIdAndVersion',T(com.vgosoft.core.util.VCurrentUserUtil).getCurrentTenantId(),{'java.lang.String',#p0},{'java.lang.Integer',#p1}})")
    public List<SensitiveCategory> selectByColumnIdAndVersion(String id, Integer version) {
        return mapper.selectByColumnIdAndVersion(id,version);
    }

    @Override
    @Cacheable(cacheNames = {"SensitiveCategory#8h"},unless = "#result==null || #result instanceof T(java.lang.Exception) || (#result instanceof T(java.util.Collection) && #result.isEmpty())",key = "#root.target.vgosoftCacheKeyJson({'vgosoft-cache-key-v3','SensitiveCategory','com.vgosoft.sensitive.entity.SensitiveCategory#selectByColumnIds',T(com.vgosoft.core.util.VCurrentUserUtil).getCurrentTenantId(),{'java.util.List<java.lang.String>',#p0}})")
    public List<SensitiveCategory> selectByColumnIds(List<String> ids) {
        return mapper.selectByColumnIds(ids);
    }

    @Override
    @org.springframework.transaction.annotation.Transactional(propagation = org.springframework.transaction.annotation.Propagation.REQUIRED, rollbackFor = Exception.class)
    @CacheEvict(cacheNames = {"SensitiveCategory#8h"},allEntries = true)
    public int deleteByColumnIdAndVersion(String id, Integer version) {
        org.springframework.util.Assert.notNull(id, "删除条件不能为空：id");
        org.springframework.util.Assert.notNull(version, "删除条件不能为空：version");
        org.springframework.util.Assert.isTrue(version > 0 && version < Integer.MAX_VALUE, "旧版本必须为可递增的正数");
        int affected = mapper.deleteByColumnIdAndVersion(id, version);
        if (affected != 1) {
            throw new IllegalStateException("LOGICAL_DELETE_CONFLICT");
        }
        return affected;
    }

    @Override
    @Cacheable(cacheNames = {"SensitiveCategory#8h"},unless = "#result==null || #result instanceof T(java.lang.Exception) || #result.isEmpty()",key = "#root.target.vgosoftCacheKeyJson({'vgosoft-cache-key-v3','SensitiveCategory','com.vgosoft.sensitive.entity.SensitiveCategory#selectByKeysDict',T(com.vgosoft.core.util.VCurrentUserUtil).getCurrentTenantId(),{'java.util.Optional<java.lang.String>',(#p0 == null ? 'null' : (#p0.isPresent() ? 'present' : 'empty')),(#p0 != null && #p0.isPresent() ? #p0.get() : null)},{'java.lang.String',#p1}})")
    public List<SensitiveCategoryCachePo> selectByKeysDict(Optional<String> types, String keys) {
        return queryByKeysDict(types, keys);
    }

    /**
     * 查询请求级字典预取所需的数据，不读取或写入 Spring 缓存。
     * @param types 可选字典类型
     * @param keys 逗号分隔的字典键
     * @return 按配置排序的缓存模型列表
     */
    @DictPrefetchProvider(keyProperty = "id", orderProperties = {"sort", "created", "id"}, uniqueOrderProperties = {"id"})
    @Override
    public List<SensitiveCategoryCachePo> selectByKeysDictForPrefetch(Optional<String> types, String keys) {
        return queryByKeysDict(types, keys);
    }

    private List<SensitiveCategoryCachePo> queryByKeysDict(Optional<String> types, String keys) {
        SelDictByKeysParam selDictByKeysParam = new SelDictByKeysParam();
        selDictByKeysParam.addKeyString(keys);
        if (types!=null && types.isPresent()) {
            types.ifPresent(selDictByKeysParam::addTypeString);
        }
        List<SensitiveCategory> result = mapper.selectByKeysDict(selDictByKeysParam);
        if (!result.isEmpty()) {
            return sensitiveCategoryCachePoMappingsImpl.toSensitiveCategoryCachePos(result);
        }else{
            return new ArrayList<>();
        }
    }

    @Override
    public List<SensitiveCategory> selectByPrimaryKeys(@Nullable String ids) {
        if (!VStringUtil.stringHasValue(ids)) {
            return this.selectByExample(new SensitiveCategoryExample()).getResult();
        } else {
            return Arrays.stream(ids.split(","))
                    .map(this::selectByPrimaryKey)
                    .filter(ServiceResult::hasResult)
                    .map(ServiceResult::getResult)
                    .collect(Collectors.toList());
        }
    }

    @CacheEvict(cacheNames = {"SensitiveCategory#8h"},allEntries = true)
    @Override
    public ServiceResult<SensitiveCategory> insert(SensitiveCategory record) {
        try {
            int i = mapper.insert(record);
            if (i > 0) {
                return ServiceResult.success(record, i);
            } else {
                return ServiceResult.failure(ServiceCodeEnum.WARN, "插入失败");
            }
        } catch (Exception e) {
            throw new VgoException(ServiceCodeEnum.FAIL.code(), e.getMessage());
        }
    }

    @CacheEvict(cacheNames = {"SensitiveCategory#8h"},allEntries = true)
    @Override
    public ServiceResult<SensitiveCategory> insertSelective(SensitiveCategory record) {
        try {
            int i = mapper.insertSelective(record);
            if (i > 0) {
                return ServiceResult.success(record, i);
            } else {
                return ServiceResult.failure(ServiceCodeEnum.WARN, "插入失败");
            }
        } catch (Exception e) {
            throw new VgoException(ServiceCodeEnum.FAIL.code(), e.getMessage());
        }
    }

    @Override
    @CacheEvict(cacheNames = {"SensitiveCategory#8h"},allEntries = true)
    public ServiceResult<Integer> deleteByExample(SensitiveCategoryExample example) {
        ServiceResult<List<SensitiveCategory>> result = this.selectByExample(example);
        List<SensitiveCategory> items = result.getResult();
        int affectedRows = mapper.deleteByExample(example);
        if (affectedRows > 0) {
            return ServiceResult.success(affectedRows,affectedRows);
        }
        return ServiceResult.failure(ServiceCodeEnum.FAIL);
    }

    @Override
    @CacheEvict(cacheNames = {"SensitiveCategory#8h"},allEntries = true)
    public ServiceResult<Integer> deleteByPrimaryKey(String id) {
        return super.deleteByPrimaryKey(id);
    }

    @Override
    @Transactional(rollbackFor = Exception.class, isolation = Isolation.READ_COMMITTED)
    @CacheEvict(cacheNames = {"SensitiveCategory#8h"},allEntries = true)
    public ServiceResult<Integer> updateByExampleSelective(SensitiveCategory record, SensitiveCategoryExample example) {
        return super.updateByExampleSelective(record, example);
    }

    @Override
    @CacheEvict(cacheNames = {"SensitiveCategory#8h"},allEntries = true)
    public ServiceResult<Integer> updateByExample(SensitiveCategory record, SensitiveCategoryExample example) {
        return super.updateByExample(record, example);
    }

    @Override
    @Transactional(rollbackFor = Exception.class, isolation = Isolation.READ_COMMITTED)
    @CacheEvict(cacheNames = {"SensitiveCategory#8h"},allEntries = true)
    public ServiceResult<SensitiveCategory> updateByPrimaryKeySelective(SensitiveCategory record) {
        try {
            int i = mapper.updateByPrimaryKeySelective(record);
            return ServiceResult.success(record, i);
        } catch (Exception e) {
            throw new VgoException(ServiceCodeEnum.FAIL.code(), e.getMessage());
        }
    }

    @Override
    @CacheEvict(cacheNames = {"SensitiveCategory#8h"},allEntries = true)
    public ServiceResult<SensitiveCategory> updateByPrimaryKey(SensitiveCategory record) {
        try {
            int i = mapper.updateByPrimaryKey(record);
            return ServiceResult.success(record, i);
        } catch (Exception e) {
            throw new VgoException(ServiceCodeEnum.FAIL.code(), e.getMessage());
        }
    }

    @Override
    @CacheEvict(cacheNames = {"SensitiveCategory#8h"},allEntries = true,condition = "#p0.table == null || #p0.table.trim().equalsIgnoreCase('sensitive_category') || #p0.table.trim().equalsIgnoreCase('sensitive_category as sc')")
    public ServiceResult<Integer> updateBySql(UpdateSqlBuilder updateSqlBuilder) {
        return super.updateBySql(updateSqlBuilder);
    }

    @Override
    @CacheEvict(cacheNames = {"SensitiveCategory#8h"},allEntries = true,condition = "#p0.table == null || #p0.table.trim().equalsIgnoreCase('sensitive_category') || #p0.table.trim().equalsIgnoreCase('sensitive_category as sc')")
    public ServiceResult<Integer> insertBySql(InsertSqlBuilder insertSqlBuilder) {
        return super.insertBySql(insertSqlBuilder);
    }

    @Override
    @CacheEvict(cacheNames = {"SensitiveCategory#8h"},allEntries = true)
    public ServiceResult<SensitiveCategory> insertOrUpdateSelective(SensitiveCategory record) {
        return super.insertOrUpdateSelective(record);
    }

    @Override
    @CacheEvict(cacheNames = {"SensitiveCategory#8h"},allEntries = true)
    public ServiceResult<List<SensitiveCategory>> updateByExampleSelectiveAndSelect(SensitiveCategory record, SensitiveCategoryExample example) {
        return super.updateByExampleSelectiveAndSelect(record, example);
    }
}