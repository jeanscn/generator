package com.vgosoft.sensitive.controller;

import static com.vgosoft.core.constant.CacheConstant.CACHE_MANAGER_NAME;

import com.vgosoft.sensitive.codegen.controller.AbstractSensitiveCategoryController;
import com.vgosoft.sensitive.pojo.maps.SensitiveCategoryMappings;
import com.vgosoft.sensitive.service.ISensitiveCategory;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.web.bind.annotation.*;

@CacheConfig(cacheManager = CACHE_MANAGER_NAME)
@RestController
@RequestMapping(value = {"sensitive/sensitive-category-impl"})
public class SensitiveCategoryController extends AbstractSensitiveCategoryController {
    public SensitiveCategoryController(ISensitiveCategory sensitiveCategoryImpl, SensitiveCategoryMappings mappings) {
        super(sensitiveCategoryImpl, mappings);
    }
}