package com.vgosoft.sensitive.codegen.dao;

import com.baomidou.mybatisplus.core.mapper.Mapper;
import com.vgosoft.mybatis.inf.MBGMapperInterface;
import com.vgosoft.sensitive.entity.SensitiveAuditOutbox;
import com.vgosoft.sensitive.entity.SensitiveAuditOutboxExample;
import java.util.List;

public interface GenSensitiveAuditOutboxMapper extends MBGMapperInterface<SensitiveAuditOutbox, SensitiveAuditOutboxExample>, Mapper<SensitiveAuditOutbox> {
    int insertBatch(List<SensitiveAuditOutbox> sensitiveAuditOutboxs);

    int insertOrUpdate(SensitiveAuditOutbox sensitiveAuditOutbox);

    int updateBatchByPrimaryKey(List<SensitiveAuditOutbox> sensitiveAuditOutboxs);
}