package com.vgosoft.sensitive.pojo.vo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.vgosoft.core.util.UuidUtil;
import com.vgosoft.sensitive.pojo.abs.AbstractSensitiveCategoryVo;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serial;
import lombok.*;

@Data
@ToString(callSuper = true)
@Schema(name = "SensitiveCategoryCreateVo", description = "敏感词分类管理", implementation = AbstractSensitiveCategoryVo.class)
public class SensitiveCategoryCreateVo extends AbstractSensitiveCategoryVo {
    @Serial
    private static final long serialVersionUID = 1L;

    @Schema(description = "插入时选择性更新", example = "true")
    @TableField(exist = false)
    private boolean selectiveUpdate;

    @Schema(description = "临时数据标识", example = "''")
    @TableField(exist = false)
    private String modelTempId = UuidUtil.nextUuid();

    {
        this.version = 1;
        this.state = 1;
    }
}