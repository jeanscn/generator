package com.vgosoft.sensitive.codegen.service.impl;

import com.vgosoft.core.adapter.ServiceResult;
import com.vgosoft.core.constant.enums.core.ServiceCodeEnum;
import com.vgosoft.core.exception.VgoException;
import com.vgosoft.mybatis.abs.AbstractMybatisBGService;
import com.vgosoft.plugins.excel.listener.DefaultReadListener;
import com.vgosoft.plugins.excel.pojo.vo.VgoExcelImportConfirmVo;
import com.vgosoft.plugins.excel.pojo.vo.VgoExcelImportPreviewVo;
import com.vgosoft.plugins.excel.pojo.vo.VgoExcelImportResultVo;
import com.vgosoft.plugins.excel.service.VgoFesodSheet;
import com.vgosoft.sensitive.codegen.service.IGenSensitiveWord;
import com.vgosoft.sensitive.dao.SensitiveWordMapper;
import com.vgosoft.sensitive.entity.SensitiveWord;
import com.vgosoft.sensitive.entity.SensitiveWordExample;
import com.vgosoft.sensitive.pojo.vo.SensitiveWordExcelImportVo;
import com.vgosoft.tool.core.VStringUtil;
import jakarta.annotation.Nullable;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

public abstract class AbstractSensitiveWordImpl extends AbstractMybatisBGService<SensitiveWordMapper, SensitiveWord, SensitiveWordExample> implements IGenSensitiveWord {
    private final SensitiveWordMapper mapper;

    public AbstractSensitiveWordImpl(SensitiveWordMapper mapper) {
        super(mapper);
        this.mapper = mapper;
    }

    @Override
    public VgoExcelImportPreviewVo<SensitiveWordExcelImportVo> previewExcelImport(MultipartFile file) throws IOException {
        if (file == null || file.isEmpty()) {
            throw new IllegalArgumentException("Excel 文件不能为空");
        }
        VgoFesodSheet.BoundedReadResult<SensitiveWordExcelImportVo> parsed = VgoFesodSheet.readBounded(
                file, SensitiveWordExcelImportVo.class, new DefaultReadListener<>(),
                new VgoFesodSheet.ImportReadLimits(31457280L, 62914560L, 31457280L, 256, 100, 100));
        VgoExcelImportPreviewVo<SensitiveWordExcelImportVo> result = createExcelImportPreview(parsed.rows(), parsed.fileSha256());
        if (result == null || result.getRowCount() < 0 || result.getRowCount() > 100
                || result.getRows() == null || result.getRows().size() > 100
                || result.getErrors() == null || result.getErrors().size() > 100) {
            throw new IllegalStateException("Excel 导入预览结果超过配置限额或未返回有效结果");
        }
        return result;
    }

    protected VgoExcelImportPreviewVo<SensitiveWordExcelImportVo> createExcelImportPreview(List<SensitiveWordExcelImportVo> rows, String fileSha256) {
        throw new UnsupportedOperationException("请在业务服务子类中实现 Excel 导入预览策略");
    }

    @Override
    @Transactional(rollbackFor = Exception.class, isolation = Isolation.READ_COMMITTED)
    public VgoExcelImportResultVo confirmExcelImport(VgoExcelImportConfirmVo request, List<SensitiveWordExcelImportVo> rows, String fileSha256) {
        if (request == null || request.getPreviewToken() == null
                || request.getPreviewToken().trim().isEmpty()) {
            throw new IllegalArgumentException("Excel 导入预览凭证不能为空");
        }
        if (rows == null || rows.size() > 100 || fileSha256 == null || !fileSha256.matches("[0-9a-f]{64}")) {
            throw new IllegalArgumentException("Excel 导入确认文件或解析结果无效");
        }
        VgoExcelImportResultVo result = doConfirmExcelImport(request, rows, fileSha256);
        if (result == null || result.getImportedRows() < 0 || result.getImportedRows() > 100) {
            throw new IllegalStateException("Excel 导入确认策略未返回有效结果");
        }
        return result;
    }

    protected VgoExcelImportResultVo doConfirmExcelImport(VgoExcelImportConfirmVo request, List<SensitiveWordExcelImportVo> rows, String fileSha256) {
        throw new UnsupportedOperationException("请在业务服务子类中实现 Excel 导入确认策略");
    }

    @Override
    public ServiceResult<List<SensitiveWord>> insertBatch(List<SensitiveWord> sensitiveWords) {
        int i = mapper.insertBatch(sensitiveWords);
        if (i > 0) {
            return ServiceResult.success(sensitiveWords,i);
        }else{
            return ServiceResult.failure(ServiceCodeEnum.WARN);
        }
    }

    @Override
    public ServiceResult<List<SensitiveWord>> updateBatchByPrimaryKey(List<SensitiveWord> sensitiveWords) {
        try {
            int i = mapper.updateBatchByPrimaryKey(sensitiveWords);
            return ServiceResult.success(sensitiveWords, i);
        } catch (Exception e) {
            throw new VgoException(ServiceCodeEnum.FAIL.code(), e.getMessage());
        }
    }

    /**
     * 根据完整主键锁定并查询记录。
     * 必须在非只读既有事务中调用；锁持有至事务结束，数据库异常直接向外传播。
     * 不经过查询缓存；可见版本取决于数据库和事务隔离级别。
     * @param id 完整主键值
     * @return 锁定查询结果的服务包装
     * @throws IllegalStateException 未开启事务、只读事务或存在分页上下文
     * @throws IllegalArgumentException 查询条件不符合锁定查询约束
     */
    @Override
    @org.springframework.transaction.annotation.Transactional(propagation = org.springframework.transaction.annotation.Propagation.MANDATORY, rollbackFor = Exception.class)
    public ServiceResult<SensitiveWord> selectByPrimaryKeyForUpdate(String id) {
        com.vgosoft.sensitive.codegen.dao.GenSensitiveWordMapperLockQueryGuard.requireSelectForUpdateTransaction();
        return ServiceResult.success(mapper.selectByPrimaryKeyForUpdate(id));
    }

    /**
     * 根据明确条件锁定并查询记录，禁止全表、去重、动态排序和分页。
     * 必须在非只读既有事务中调用；锁持有至事务结束，数据库异常直接向外传播。
     * 不经过查询缓存；可见版本取决于数据库和事务隔离级别。
     * @param example 非空白名单查询条件
     * @return 锁定查询结果的服务包装
     * @throws IllegalStateException 未开启事务、只读事务或存在分页上下文
     * @throws IllegalArgumentException 查询条件不符合锁定查询约束
     */
    @Override
    @org.springframework.transaction.annotation.Transactional(propagation = org.springframework.transaction.annotation.Propagation.MANDATORY, rollbackFor = Exception.class)
    public ServiceResult<List<SensitiveWord>> selectByExampleForUpdate(SensitiveWordExample example) {
        com.vgosoft.sensitive.codegen.dao.GenSensitiveWordMapperLockQueryGuard.requireSelectForUpdateTransaction();
        com.vgosoft.sensitive.codegen.dao.GenSensitiveWordMapperLockQueryGuard.requireSelectForUpdateExample(example);
        return ServiceResult.success(mapper.selectByExampleForUpdate(example));
    }

    @Override
    public Integer updateDeleteFlag(SensitiveWord sensitiveWord, int deleteFlag) {
        sensitiveWord.setDeleteFlag(deleteFlag);
        return mapper.updateByPrimaryKey(sensitiveWord);
    }

    @Override
    public ServiceResult<SensitiveWord> insertOrUpdate(SensitiveWord sensitiveWord) {
        try {
            int i = mapper.insertOrUpdate(sensitiveWord);
            return ServiceResult.success(sensitiveWord,i);
        } catch (Exception e) {
            throw new VgoException(ServiceCodeEnum.FAIL.code(), e.getMessage());
        }
    }

    @Override
    public List<SensitiveWord> selectByColumnIdAndVersion(String id, Integer version) {
        return mapper.selectByColumnIdAndVersion(id,version);
    }

    @Override
    public List<SensitiveWord> selectByColumnIds(List<String> ids) {
        return mapper.selectByColumnIds(ids);
    }

    @Override
    @org.springframework.transaction.annotation.Transactional(propagation = org.springframework.transaction.annotation.Propagation.REQUIRED, rollbackFor = Exception.class)
    public int deleteByColumnIdAndVersion(String id, Integer version) {
        org.springframework.util.Assert.notNull(id, "删除条件不能为空：id");
        org.springframework.util.Assert.notNull(version, "删除条件不能为空：version");
        org.springframework.util.Assert.isTrue(version > 0 && version < Integer.MAX_VALUE, "旧版本必须为可递增的正数");
        int affected = mapper.deleteByColumnIdAndVersion(id, version);
        if (affected != 1) {
            throw new IllegalStateException("LOGICAL_DELETE_CONFLICT");
        }
        return affected;
    }

    @Override
    public List<SensitiveWord> selectByPrimaryKeys(@Nullable String ids) {
        if (!VStringUtil.stringHasValue(ids)) {
            return this.selectByExample(new SensitiveWordExample()).getResult();
        } else {
            return Arrays.stream(ids.split(","))
                    .map(this::selectByPrimaryKey)
                    .filter(ServiceResult::hasResult)
                    .map(ServiceResult::getResult)
                    .collect(Collectors.toList());
        }
    }
}