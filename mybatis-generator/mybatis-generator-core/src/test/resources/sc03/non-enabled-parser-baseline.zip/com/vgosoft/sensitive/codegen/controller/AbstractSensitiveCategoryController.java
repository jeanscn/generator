package com.vgosoft.sensitive.codegen.controller;

import static com.vgosoft.core.adapter.web.respone.ResponseResult.*;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.vgosoft.core.adapter.ServiceResult;
import com.vgosoft.core.adapter.web.FilterParam;
import com.vgosoft.core.adapter.web.respone.ResponseResult;
import com.vgosoft.core.annotation.SystemLog;
import com.vgosoft.core.constant.SymbolConstants;
import com.vgosoft.core.constant.enums.core.ApiCodeEnum;
import com.vgosoft.core.constant.enums.db.DefaultColumnNameEnum;
import com.vgosoft.core.valid.ValidateInsert;
import com.vgosoft.core.valid.ValidateQuery;
import com.vgosoft.core.valid.ValidateUpdate;
import com.vgosoft.mybatis.pojo.ResponsePagehelperResult;
import com.vgosoft.mybatis.sqlbuilder.SelectSqlBuilder;
import com.vgosoft.sensitive.entity.SensitiveCategory;
import com.vgosoft.sensitive.entity.SensitiveCategoryExample.Criteria;
import com.vgosoft.sensitive.entity.SensitiveCategoryExample;
import com.vgosoft.sensitive.pojo.maps.SensitiveCategoryMappings;
import com.vgosoft.sensitive.pojo.vo.SensitiveCategoryCreateVo;
import com.vgosoft.sensitive.pojo.vo.SensitiveCategoryRequestVo;
import com.vgosoft.sensitive.pojo.vo.SensitiveCategoryUpdateVo;
import com.vgosoft.sensitive.pojo.vo.SensitiveCategoryVo;
import com.vgosoft.sensitive.service.ISensitiveCategory;
import com.vgosoft.system.web.FormSelectOption;
import com.vgosoft.tool.ValidList;
import com.vgosoft.tool.core.VStringUtil;
import com.vgosoft.web.controller.abs.AbstractBaseController;
import com.vgosoft.web.plugins.datatables.DataTablesConfig;
import com.vgosoft.web.plugins.datatables.DataTablesMappings;
import com.vgosoft.web.plugins.datatables.util.DataTablesUtil;
import com.vgosoft.web.pojo.vo.ViewDtTableVo;
import com.vgosoft.web.utils.ParameterUtil;
import io.swagger.v3.oas.annotations.Operation;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

public abstract class AbstractSensitiveCategoryController extends AbstractBaseController<SensitiveCategory, SensitiveCategoryVo> {
    private final ISensitiveCategory sensitiveCategoryImpl;

    private final SensitiveCategoryMappings mappings;

    public AbstractSensitiveCategoryController(ISensitiveCategory sensitiveCategoryImpl, SensitiveCategoryMappings mappings) {
        this.sensitiveCategoryImpl = sensitiveCategoryImpl;
        this.mappings = mappings;
    }

    @SystemLog(value = "敏感词分类管理:实例化空对象")
    @GetMapping(value = {"new-instance"})
    @Operation(summary = "实例化对象", description = "实例化一个空对象，供前端使用")
    protected ResponseResult<SensitiveCategoryVo> newInstanceSensitiveCategory(SensitiveCategoryCreateVo sensitiveCategoryCreateVo) {
        SensitiveCategory sensitiveCategory = mappings.fromSensitiveCategoryCreateVo(sensitiveCategoryCreateVo);
        SensitiveCategoryVo object = mappings.toSensitiveCategoryVo(sensitiveCategory);
        return ResponseResult.success(updateNewInstanceDefaultValue(object));
    }

    @SystemLog(value = "敏感词分类管理:根据主键查询单条")
    @GetMapping(value = {"{id}"})
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivecategoryimpl:get')")
    @Operation(summary = "获得单条记录", description = "根据给定id获取单个实体")
    protected ResponseResult<SensitiveCategoryVo> getSensitiveCategory(@PathVariable String id) {
        ServiceResult<SensitiveCategory> serviceResult = sensitiveCategoryImpl.selectByPrimaryKey(id);
        if (serviceResult.hasResult()) {
            return success(mappings.toSensitiveCategoryVo(serviceResult.getResult()));
        } else {
            return failure(ApiCodeEnum.FAIL_NOT_FOUND, "敏感词分类管理数据记录");
        }
    }

    @SystemLog(value = "敏感词分类管理:查看数据列表")
    @GetMapping()
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivecategoryimpl:list')")
    @Operation(summary = "获得列表数据", description = "根据给定条件获取多条或所有数据列表，可以根据需要传入属性同名参数")
    protected ResponseResult<List<SensitiveCategoryVo>> listSensitiveCategory(@Validated(value= ValidateQuery.class) SensitiveCategoryRequestVo sensitiveCategoryRequestVo, @RequestParam(required = false) String actionType) {
        if (actionType != null) {sensitiveCategoryRequestVo.setActionType(actionType);}
        SensitiveCategoryExample example = buildExample(sensitiveCategoryRequestVo);
        ServiceResult<List<SensitiveCategory>> result;
        Page<SensitiveCategory> page = null;
        if (sensitiveCategoryRequestVo.getPageNo() == 0 || sensitiveCategoryRequestVo.getPageSize() == 0) {
            PageHelper.clearPage();
            result = sensitiveCategoryImpl.selectByExample(example);
        } else {
            PageHelper.startPage(sensitiveCategoryRequestVo.getPageNo(), sensitiveCategoryRequestVo.getPageSize());
            result = sensitiveCategoryImpl.selectByExample(example);
            page = (Page<SensitiveCategory>) result.getResult();
        }
        if (result.hasResult()) {
            if (page != null) {
                return ResponsePagehelperResult.success(mappings.toSensitiveCategoryVos(result.getResult()), page);
            } else {
                return ResponseResult.success(mappings.toSensitiveCategoryVos(result.getResult()));
            }
        } else {
            return ResponseResult.success(new ArrayList<>());
        }
    }

    @SystemLog(value = "敏感词分类管理:查看数据列表")
    @PostMapping(value = {"list"})
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivecategoryimpl:list')")
    @Operation(summary = "获得列表数据", description = "根据给定条件获取多条或所有数据列表，可以根据需要传入属性同名参数")
    protected ResponseResult<List<SensitiveCategoryVo>> listPostSensitiveCategory(@RequestBody SensitiveCategoryRequestVo sensitiveCategoryRequestVo, @RequestParam(required = false) String actionType) {
        if (actionType != null) {sensitiveCategoryRequestVo.setActionType(actionType);}
        SensitiveCategoryExample example = buildExample(sensitiveCategoryRequestVo);
         FilterParam filterParam = sensitiveCategoryRequestVo.getFilterParam();
         if (filterParam != null) {
            String filterSql = ParameterUtil.parseFilterMap(filterParam, "sc");
            if (VStringUtil.stringHasValue(filterSql)) {
                 example.getOredCriteria().forEach(criteria -> criteria.andAnyCondition(filterSql));
            }
        }
        ServiceResult<List<SensitiveCategory>> result;
        Page<SensitiveCategory> page = null;
        if (sensitiveCategoryRequestVo.getPageNo() == 0 || sensitiveCategoryRequestVo.getPageSize() == 0) {
            PageHelper.clearPage();
            result = sensitiveCategoryImpl.selectByExample(example);
        } else {
            PageHelper.startPage(sensitiveCategoryRequestVo.getPageNo(), sensitiveCategoryRequestVo.getPageSize());
            result = sensitiveCategoryImpl.selectByExample(example);
            page = (Page<SensitiveCategory>) result.getResult();
        }
        if (result.hasResult()) {
            if (page != null) {
                return ResponsePagehelperResult.success(mappings.toSensitiveCategoryVos(result.getResult()), page);
            } else {
                return ResponseResult.success(mappings.toSensitiveCategoryVos(result.getResult()));
            }
        } else {
            return ResponseResult.success(new ArrayList<>());
        }
    }

    @SystemLog(value = "敏感词分类管理:添加了一条记录")
    @PostMapping()
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivecategoryimpl:create')")
    @Operation(summary = "新增一条记录", description = "新增一条记录,返回json，包含影响条数及消息")
    protected ResponseResult<SensitiveCategoryVo> createSensitiveCategory(@Validated(value= ValidateInsert.class) @RequestBody SensitiveCategoryCreateVo sensitiveCategoryCreateVo) {
        ServiceResult<SensitiveCategory> serviceResult;
        if (sensitiveCategoryCreateVo.isSelectiveUpdate() && VStringUtil.isNotBlank(sensitiveCategoryCreateVo.getId())) {
            serviceResult = sensitiveCategoryImpl.updateByPrimaryKeySelective(mappings.fromSensitiveCategoryCreateVo(sensitiveCategoryCreateVo));
        } else if (sensitiveCategoryCreateVo.isSelectiveUpdate()) {
            serviceResult = sensitiveCategoryImpl.insertSelective(mappings.fromSensitiveCategoryCreateVo(sensitiveCategoryCreateVo));
        } else if (VStringUtil.isNotBlank(sensitiveCategoryCreateVo.getId())) {
            serviceResult = sensitiveCategoryImpl.updateByPrimaryKey(mappings.fromSensitiveCategoryCreateVo(sensitiveCategoryCreateVo));
        } else {
            serviceResult = sensitiveCategoryImpl.insert(mappings.fromSensitiveCategoryCreateVo(sensitiveCategoryCreateVo));
        }
        if (!serviceResult.isSuccess()) {
            serviceResult = sensitiveCategoryImpl.insertOrUpdate(mappings.fromSensitiveCategoryCreateVo(sensitiveCategoryCreateVo));
        }
        if (serviceResult.hasResult()) {
            return success(mappings.toSensitiveCategoryVo(serviceResult.getResult()),serviceResult.getAffectedRows());
        }else{
            return failure(ApiCodeEnum.FAIL_CUSTOM,serviceResult.getMessage());
        }
    }

    @SystemLog(value = "敏感词分类管理:添加了多条记录")
    @PostMapping(value = {"batch"})
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivecategoryimpl:createbatch')")
    @Operation(summary = "新增多条记录", description = "新增多条记录,返回影响条数及消息")
    protected ResponseResult<List<SensitiveCategoryVo>> createBatchSensitiveCategory(@Validated(value= ValidateInsert.class) @RequestBody ValidList<SensitiveCategoryCreateVo> sensitiveCategoryCreateVos) {
        ServiceResult<List<SensitiveCategory>> serviceResult = sensitiveCategoryImpl.insertBatch(mappings.fromSensitiveCategoryCreateVos(sensitiveCategoryCreateVos));
        if (serviceResult.hasResult()) {
            return success(mappings.toSensitiveCategoryVos(serviceResult.getResult()),serviceResult.getAffectedRows());
        }else{
            return failure(ApiCodeEnum.FAIL_CUSTOM,serviceResult.getMessage());
        }
    }

    @SystemLog(value = "敏感词分类管理:更新了一条记录")
    @PutMapping()
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivecategoryimpl:update')")
    @Operation(summary = "更新一条记录", description = "根据主键更新数据")
    protected ResponseResult<SensitiveCategoryVo> updateSensitiveCategory(@Validated(value= ValidateUpdate.class) @RequestBody SensitiveCategoryUpdateVo sensitiveCategoryUpdateVo) {
        ServiceResult<SensitiveCategory> serviceResult = sensitiveCategoryImpl.updateByPrimaryKeySelective(mappings.fromSensitiveCategoryUpdateVo(sensitiveCategoryUpdateVo));
        if (serviceResult.hasResult()) {
            return success(mappings.toSensitiveCategoryVo(serviceResult.getResult()),serviceResult.getAffectedRows());
        }else{
            return failure(ApiCodeEnum.FAIL_CUSTOM,serviceResult.getMessage());
        }
    }

    @SystemLog(value = "敏感词分类管理:更新了多条记录")
    @PutMapping(value = {"batch"})
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivecategoryimpl:updatebatch')")
    @Operation(summary = "批量更新数据", description = "根据主键批量更新数据")
    protected ResponseResult<List<SensitiveCategoryVo>> updateBatchSensitiveCategory(@Validated(value= ValidateUpdate.class) @RequestBody ValidList<SensitiveCategoryUpdateVo> sensitiveCategoryUpdateVos) {
        ServiceResult<List<SensitiveCategory>> result =  sensitiveCategoryImpl.updateBatchByPrimaryKey(mappings.fromSensitiveCategoryUpdateVos(sensitiveCategoryUpdateVos));
        if (result.hasResult()) {
            return success(mappings.toSensitiveCategoryVos(result.getResult()),result.getAffectedRows());
        }else{
            return failure(ApiCodeEnum.FAIL_CUSTOM,result.getMessage());
        }
    }

    @SystemLog(value = "敏感词分类管理:删除了一条记录")
    @DeleteMapping(value = {"{id}"})
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivecategoryimpl:delete')")
    @Operation(summary = "单条记录删除", description = "根据给定的id删除一条记录")
    protected ResponseResult<Long> deleteSensitiveCategory(@PathVariable String id) {
        ServiceResult<Integer> result =  sensitiveCategoryImpl.deleteByPrimaryKey(id);
        if (result.hasResult() && result.getResult() > 0) {
            return success((long) result.getResult(),result.getAffectedRows());
        } else {
            return failure(ApiCodeEnum.FAIL_CUSTOM,result.getMessage());
        }
    }

    @SystemLog(value = "敏感词分类管理:删除了一条或多条记录")
    @DeleteMapping()
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivecategoryimpl:deletebatch')")
    @Operation(summary = "批量记录删除", description = "根据给定的一组id删除多条记录")
    protected ResponseResult<Long> deleteBatchSensitiveCategory(@RequestBody List<String> ids) {
        SensitiveCategoryExample example = new SensitiveCategoryExample();
        example.createCriteria().andIdIn(ids);
        ServiceResult<Integer> result =  sensitiveCategoryImpl.deleteByExample(example);
        if (result.hasResult() && result.getResult() > 0) {
            return success((long) result.getResult(),result.getAffectedRows());
        } else {
            return failure(ApiCodeEnum.FAIL_CUSTOM,result.getMessage());
        }
    }

    @SystemLog(value = "敏感词分类管理:查看表默认视图配置")
    @PostMapping(value = {"dt/view-default"})
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivecategoryimpl:getdefaultviewconfig')")
    @Operation(summary = "默认数据视图配置", description = "获取默认数据视图配置")
    protected ResponseResult<DataTablesConfig> getDefaultViewConfigSensitiveCategory() {
        Optional<ViewDtTableVo> result = DataTablesUtil
                .getSingleViewDtTableByAnnotation(DataTablesUtil.getDefaultViewId("sensitiveCategoryImpl"), true);
        return result.map(viewDtTableVo -> success(DataTablesMappings.INSTANCE.fromViewDtTableVo(viewDtTableVo)))
                .orElseGet(() -> failure(ApiCodeEnum.FAIL_NOT_FOUND,"默认列表配置"));
    }

    @SystemLog(value = "敏感词分类管理:查看默认视图")
    @GetMapping(value = {"dt/view-default/show"})
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivecategoryimpl:getdefaultview')")
    @Operation(summary = "默认数据视图显示", description = "显示默认数据视图")
    protected ModelAndView getDefaultViewSensitiveCategory() {
        ModelAndView modelAndView = new ModelAndView("vgoweb/view/DataTables");
        modelAndView.addObject("viewId", DataTablesUtil.getDefaultViewId("sensitiveCategoryImpl"));
        modelAndView.addObject("listName", "敏感词分类管理");
        return modelAndView;
    }

    @SystemLog(value = "敏感词分类管理:调用数据选项接口")
    @GetMapping(value = {"option/name"})
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivecategoryimpl:optionname')")
    @Operation(summary = "获取Options-XX选项列表", description = "根据给定条件获取Options-XXX选项列表，可以根据需要传入属性同名参数、消费端选中的值")
    protected ResponseResult<List<FormSelectOption>> optionNameSensitiveCategory(SensitiveCategoryRequestVo sensitiveCategoryRequestVo, @RequestParam(required = false) String selected, @RequestParam(required = false) String actionType) {
        if (actionType != null) { sensitiveCategoryRequestVo.setActionType(actionType);}
        SensitiveCategoryExample example = buildExample(sensitiveCategoryRequestVo);
        ServiceResult<List<SensitiveCategory>> result;
        Page<SensitiveCategory> page = null;
        if (sensitiveCategoryRequestVo.getPageNo() == 0 || sensitiveCategoryRequestVo.getPageSize() == 0) {
            PageHelper.clearPage();
            result = sensitiveCategoryImpl.selectByExample(example);
        } else {
            PageHelper.startPage(sensitiveCategoryRequestVo.getPageNo(), sensitiveCategoryRequestVo.getPageSize());
            result = sensitiveCategoryImpl.selectByExample(example);
            page = (Page<SensitiveCategory>) result.getResult();
        }
        List<FormSelectOption> options = result.getResult().stream()
                .sorted(Comparator.comparing(SensitiveCategory::getSort))
                .map(t -> new FormSelectOption(t.getId(), t.getName(), selected))
                .distinct().collect(Collectors.toList());
        if (page!=null) {
            return ResponsePagehelperResult.success(options,page);
        } else {
            return ResponseResult.success(options);
        }
    }

    @PostMapping(value = {"select-by-column-ids"})
    @Operation(summary = "根据指定列（多值）获取匹配的记录集合", description = "根据指定列（多值）获取匹配的记录集合接口")
    protected ResponseResult<List<SensitiveCategoryVo>> selectByColumnIdsSensitiveCategory(@RequestBody Map<String, List<String>> paramsMap) {
        List<String> ids = paramsMap.get("ids");
         if (ids.isEmpty()) {
            return ResponseResult.failure(ApiCodeEnum.FAIL_CUSTOM, "id列表不能为空");
        }
        List<SensitiveCategory> sensitiveCategorys = sensitiveCategoryImpl.selectByColumnIds(ids);
        if (!sensitiveCategorys.isEmpty()) {
            List<SensitiveCategoryVo> sensitiveCategoryVos = mappings.toSensitiveCategoryVos(sensitiveCategorys);
            return ResponseResult.success(sensitiveCategoryVos);
        } else {
            return ResponseResult.failure(ApiCodeEnum.NOT_FOUND, "未找到对应的记录");
        }
    }

    @Override
    protected Page<SensitiveCategory> getListData(String beanName, SelectSqlBuilder selectSqlBuilder, List<SensitiveCategoryVo> returnResult) {
        ServiceResult<List<SensitiveCategory>> result = sensitiveCategoryImpl.selectBySql(selectSqlBuilder);
        if (result.hasResult()) {
            returnResult.addAll(mappings.toSensitiveCategoryVos(result.getResult()));
        }else{
            returnResult.addAll(new ArrayList<>());
        }
        return (Page<SensitiveCategory>) result.getResult();
    }

    protected SensitiveCategoryExample buildExample(SensitiveCategoryRequestVo sensitiveCategoryRequestVo) {
        SensitiveCategoryExample example = new SensitiveCategoryExample();
        SensitiveCategoryExample.Criteria criteria = example.createCriteria();
        if (sensitiveCategoryRequestVo.isIgnoreDeleteFlag()) {example.setIgnoreDeleteFlag(true);}
        if (sensitiveCategoryRequestVo.isIgnorePermissionAnnotation()) {example.setIgnorePermissionAnnotation(true);}
        if (!VStringUtil.isBlank(sensitiveCategoryRequestVo.getId())) {
            if (VStringUtil.indexOf(sensitiveCategoryRequestVo.getId(), SymbolConstants.COMMA.charAt(0)) > -1) {
                criteria.andIdAnyCondition("regexp '(^|,)(" + sensitiveCategoryRequestVo.getId().replace(SymbolConstants.COMMA, SymbolConstants.PIPE) + ")(,|$)'" );
            }else{
                criteria.andIdEqualTo(sensitiveCategoryRequestVo.getId());
            }
        }
        if (sensitiveCategoryRequestVo.getVersion() != null) {
            criteria.andVersionEqualTo(sensitiveCategoryRequestVo.getVersion());
        }
        if (sensitiveCategoryRequestVo.getSort() != null) {
            criteria.andSortEqualTo(sensitiveCategoryRequestVo.getSort());
        }
        if (sensitiveCategoryRequestVo.getState() != null) {
            criteria.andStateEqualTo(sensitiveCategoryRequestVo.getState());
        }
        if (!VStringUtil.isBlank(sensitiveCategoryRequestVo.getCode())) {
            if (VStringUtil.indexOf(sensitiveCategoryRequestVo.getCode(), SymbolConstants.COMMA.charAt(0)) > -1) {
                criteria.andCodeAnyCondition("regexp '(^|,)(" + sensitiveCategoryRequestVo.getCode().replace(SymbolConstants.COMMA, SymbolConstants.PIPE) + ")(,|$)'" );
            }else{
                criteria.andCodeEqualTo(sensitiveCategoryRequestVo.getCode());
            }
        }
        if (!VStringUtil.isBlank(sensitiveCategoryRequestVo.getName())) {
            if (VStringUtil.indexOf(sensitiveCategoryRequestVo.getName(), SymbolConstants.COMMA.charAt(0)) > -1) {
                criteria.andNameAnyCondition("regexp '(^|,)(" + sensitiveCategoryRequestVo.getName().replace(SymbolConstants.COMMA, SymbolConstants.PIPE) + ")(,|$)'" );
            }else{
                criteria.andNameEqualTo(sensitiveCategoryRequestVo.getName());
            }
        }
        if (!VStringUtil.isBlank(sensitiveCategoryRequestVo.getNotes())) {
            if (VStringUtil.indexOf(sensitiveCategoryRequestVo.getNotes(), SymbolConstants.COMMA.charAt(0)) > -1) {
                criteria.andNotesAnyCondition("regexp '(^|,)(" + sensitiveCategoryRequestVo.getNotes().replace(SymbolConstants.COMMA, SymbolConstants.PIPE) + ")(,|$)'" );
            }else{
                criteria.andNotesEqualTo(sensitiveCategoryRequestVo.getNotes());
            }
        }
        if (!VStringUtil.isBlank(sensitiveCategoryRequestVo.getAnyWhereCondition())) {
            criteria.andAnyCondition(sensitiveCategoryRequestVo.getAnyWhereCondition());
        }
        List<String> orderBy = new ArrayList<>();
        String orderByClause = sensitiveCategoryRequestVo.getOrderByClause();
        if (VStringUtil.stringHasValue(orderByClause)) {
            orderBy.add(orderByClause);
        } else {
            orderByClause = "";
        }
        if (!orderByClause.toLowerCase().contains(DefaultColumnNameEnum.SORT.columnName())) {
            orderBy.add(DefaultColumnNameEnum.SORT.columnName()+" asc");
        }
        if (!orderByClause.toLowerCase().contains(DefaultColumnNameEnum.CREATE_TIME.columnName())) {
            orderBy.add(DefaultColumnNameEnum.CREATE_TIME.columnName()+" desc");
        }
        if (!orderBy.isEmpty()) {
            example.setOrderByClause(String.join(SymbolConstants.COMMA, orderBy));
        }
        return example;
    }

    protected List<Criteria> getCriteriaList(SensitiveCategoryExample example) {
        List<SensitiveCategoryExample.Criteria> criteriaList = new ArrayList<>(example.getOredCriteria());
        if (criteriaList.isEmpty()) {
            criteriaList.add(example.createCriteria());
        }
        return criteriaList;
    }
}