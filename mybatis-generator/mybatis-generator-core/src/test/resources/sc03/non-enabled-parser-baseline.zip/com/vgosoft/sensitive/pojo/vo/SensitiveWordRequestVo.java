package com.vgosoft.sensitive.pojo.vo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.vgosoft.core.adapter.web.FilterParam;
import com.vgosoft.core.pojo.IPage;
import com.vgosoft.sensitive.pojo.abs.AbstractSensitiveWordVo;
import io.swagger.v3.oas.annotations.media.Schema;
import java.io.Serial;
import java.util.List;
import lombok.*;

@Data
@ToString(callSuper = true)
@Schema(name = "SensitiveWordRequestVo", description = "敏感词管理", implementation = AbstractSensitiveWordVo.class)
public class SensitiveWordRequestVo extends AbstractSensitiveWordVo implements IPage {
    @Serial
    private static final long serialVersionUID = 1L;

    private Integer state;

    private String word;

    @Schema(description = "页码", example = "1")
    private int pageNo = DEFAULT_FIRST_PAGE_NO;

    @Schema(description = "每页数据数量", example = "10")
    private int pageSize = DEFAULT_PAGE_SIZE;

    @Schema(description = "排序语句", example = "SORT_")
    private String orderByClause;

    @Schema(description = "是否忽略删除标记", example = "false")
    private boolean ignoreDeleteFlag;

    @Schema(description = "是否忽略权限注解", example = "false")
    private boolean ignorePermissionAnnotation;

    @Schema(description = "查询忽略id列表", example = "[]")
    private List<String> ignoreIdList;

    @Schema(description = "是否忽略隐藏id列表", example = "false")
    private boolean isHideIds;

    private String anyWhereCondition;

    @Schema(description = "前端过滤器及类似查询过滤条件", example = "filterParam = ‘{}’")
    private FilterParam filterParam;

    @Schema(description = "查询应用场景的类型标识", example = "selector")
    private String actionType;
}