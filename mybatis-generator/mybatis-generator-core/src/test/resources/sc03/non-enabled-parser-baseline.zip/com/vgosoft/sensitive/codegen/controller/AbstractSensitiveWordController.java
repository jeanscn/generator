package com.vgosoft.sensitive.codegen.controller;

import static com.vgosoft.core.adapter.web.respone.ResponseResult.*;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.vgosoft.core.adapter.ServiceResult;
import com.vgosoft.core.adapter.web.FilterParam;
import com.vgosoft.core.adapter.web.respone.ResponseResult;
import com.vgosoft.core.annotation.SystemLog;
import com.vgosoft.core.constant.SymbolConstants;
import com.vgosoft.core.constant.enums.core.ApiCodeEnum;
import com.vgosoft.core.constant.enums.db.DefaultColumnNameEnum;
import com.vgosoft.core.valid.ValidateInsert;
import com.vgosoft.core.valid.ValidateQuery;
import com.vgosoft.core.valid.ValidateUpdate;
import com.vgosoft.mybatis.pojo.ResponsePagehelperResult;
import com.vgosoft.mybatis.sqlbuilder.SelectSqlBuilder;
import com.vgosoft.sensitive.entity.SensitiveWord;
import com.vgosoft.sensitive.entity.SensitiveWordExample.Criteria;
import com.vgosoft.sensitive.entity.SensitiveWordExample;
import com.vgosoft.sensitive.pojo.maps.SensitiveWordMappings;
import com.vgosoft.sensitive.pojo.vo.SensitiveWordCreateVo;
import com.vgosoft.sensitive.pojo.vo.SensitiveWordRequestVo;
import com.vgosoft.sensitive.pojo.vo.SensitiveWordUpdateVo;
import com.vgosoft.sensitive.pojo.vo.SensitiveWordVo;
import com.vgosoft.sensitive.service.ISensitiveWord;
import com.vgosoft.tool.ValidList;
import com.vgosoft.tool.core.VStringUtil;
import com.vgosoft.web.controller.abs.AbstractBaseController;
import com.vgosoft.web.plugins.datatables.DataTablesConfig;
import com.vgosoft.web.plugins.datatables.DataTablesMappings;
import com.vgosoft.web.plugins.datatables.util.DataTablesUtil;
import com.vgosoft.web.pojo.vo.ViewDtTableVo;
import com.vgosoft.web.utils.ParameterUtil;
import io.swagger.v3.oas.annotations.Operation;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

public abstract class AbstractSensitiveWordController extends AbstractBaseController<SensitiveWord, SensitiveWordVo> {
    private final ISensitiveWord sensitiveWordImpl;

    private final SensitiveWordMappings mappings;

    public AbstractSensitiveWordController(ISensitiveWord sensitiveWordImpl, SensitiveWordMappings mappings) {
        this.sensitiveWordImpl = sensitiveWordImpl;
        this.mappings = mappings;
    }

    @SystemLog(value = "敏感词管理:实例化空对象")
    @GetMapping(value = {"new-instance"})
    @Operation(summary = "实例化对象", description = "实例化一个空对象，供前端使用")
    protected ResponseResult<SensitiveWordVo> newInstanceSensitiveWord(SensitiveWordCreateVo sensitiveWordCreateVo) {
        SensitiveWord sensitiveWord = mappings.fromSensitiveWordCreateVo(sensitiveWordCreateVo);
        SensitiveWordVo object = mappings.toSensitiveWordVo(sensitiveWord);
        return ResponseResult.success(updateNewInstanceDefaultValue(object));
    }

    @SystemLog(value = "敏感词管理:根据主键查询单条")
    @GetMapping(value = {"{id}"})
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivewordimpl:get')")
    @Operation(summary = "获得单条记录", description = "根据给定id获取单个实体")
    protected ResponseResult<SensitiveWordVo> getSensitiveWord(@PathVariable String id) {
        ServiceResult<SensitiveWord> serviceResult = sensitiveWordImpl.selectByPrimaryKey(id);
        if (serviceResult.hasResult()) {
            return success(mappings.toSensitiveWordVo(serviceResult.getResult()));
        } else {
            return failure(ApiCodeEnum.FAIL_NOT_FOUND, "敏感词管理数据记录");
        }
    }

    @SystemLog(value = "敏感词管理:查看数据列表")
    @GetMapping()
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivewordimpl:list')")
    @Operation(summary = "获得列表数据", description = "根据给定条件获取多条或所有数据列表，可以根据需要传入属性同名参数")
    protected ResponseResult<List<SensitiveWordVo>> listSensitiveWord(@Validated(value= ValidateQuery.class) SensitiveWordRequestVo sensitiveWordRequestVo, @RequestParam(required = false) String actionType) {
        if (actionType != null) {sensitiveWordRequestVo.setActionType(actionType);}
        SensitiveWordExample example = buildExample(sensitiveWordRequestVo);
        ServiceResult<List<SensitiveWord>> result;
        Page<SensitiveWord> page = null;
        if (sensitiveWordRequestVo.getPageNo() == 0 || sensitiveWordRequestVo.getPageSize() == 0) {
            PageHelper.clearPage();
            result = sensitiveWordImpl.selectByExample(example);
        } else {
            PageHelper.startPage(sensitiveWordRequestVo.getPageNo(), sensitiveWordRequestVo.getPageSize());
            result = sensitiveWordImpl.selectByExample(example);
            page = (Page<SensitiveWord>) result.getResult();
        }
        if (result.hasResult()) {
            if (page != null) {
                return ResponsePagehelperResult.success(mappings.toSensitiveWordVos(result.getResult()), page);
            } else {
                return ResponseResult.success(mappings.toSensitiveWordVos(result.getResult()));
            }
        } else {
            return ResponseResult.success(new ArrayList<>());
        }
    }

    @SystemLog(value = "敏感词管理:查看数据列表")
    @PostMapping(value = {"list"})
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivewordimpl:list')")
    @Operation(summary = "获得列表数据", description = "根据给定条件获取多条或所有数据列表，可以根据需要传入属性同名参数")
    protected ResponseResult<List<SensitiveWordVo>> listPostSensitiveWord(@RequestBody SensitiveWordRequestVo sensitiveWordRequestVo, @RequestParam(required = false) String actionType) {
        if (actionType != null) {sensitiveWordRequestVo.setActionType(actionType);}
        SensitiveWordExample example = buildExample(sensitiveWordRequestVo);
         FilterParam filterParam = sensitiveWordRequestVo.getFilterParam();
         if (filterParam != null) {
            String filterSql = ParameterUtil.parseFilterMap(filterParam, "sw");
            if (VStringUtil.stringHasValue(filterSql)) {
                 example.getOredCriteria().forEach(criteria -> criteria.andAnyCondition(filterSql));
            }
        }
        ServiceResult<List<SensitiveWord>> result;
        Page<SensitiveWord> page = null;
        if (sensitiveWordRequestVo.getPageNo() == 0 || sensitiveWordRequestVo.getPageSize() == 0) {
            PageHelper.clearPage();
            result = sensitiveWordImpl.selectByExample(example);
        } else {
            PageHelper.startPage(sensitiveWordRequestVo.getPageNo(), sensitiveWordRequestVo.getPageSize());
            result = sensitiveWordImpl.selectByExample(example);
            page = (Page<SensitiveWord>) result.getResult();
        }
        if (result.hasResult()) {
            if (page != null) {
                return ResponsePagehelperResult.success(mappings.toSensitiveWordVos(result.getResult()), page);
            } else {
                return ResponseResult.success(mappings.toSensitiveWordVos(result.getResult()));
            }
        } else {
            return ResponseResult.success(new ArrayList<>());
        }
    }

    @SystemLog(value = "敏感词管理:添加了一条记录")
    @PostMapping()
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivewordimpl:create')")
    @Operation(summary = "新增一条记录", description = "新增一条记录,返回json，包含影响条数及消息")
    protected ResponseResult<SensitiveWordVo> createSensitiveWord(@Validated(value= ValidateInsert.class) @RequestBody SensitiveWordCreateVo sensitiveWordCreateVo) {
        ServiceResult<SensitiveWord> serviceResult;
        if (sensitiveWordCreateVo.isSelectiveUpdate() && VStringUtil.isNotBlank(sensitiveWordCreateVo.getId())) {
            serviceResult = sensitiveWordImpl.updateByPrimaryKeySelective(mappings.fromSensitiveWordCreateVo(sensitiveWordCreateVo));
        } else if (sensitiveWordCreateVo.isSelectiveUpdate()) {
            serviceResult = sensitiveWordImpl.insertSelective(mappings.fromSensitiveWordCreateVo(sensitiveWordCreateVo));
        } else if (VStringUtil.isNotBlank(sensitiveWordCreateVo.getId())) {
            serviceResult = sensitiveWordImpl.updateByPrimaryKey(mappings.fromSensitiveWordCreateVo(sensitiveWordCreateVo));
        } else {
            serviceResult = sensitiveWordImpl.insert(mappings.fromSensitiveWordCreateVo(sensitiveWordCreateVo));
        }
        if (!serviceResult.isSuccess()) {
            serviceResult = sensitiveWordImpl.insertOrUpdate(mappings.fromSensitiveWordCreateVo(sensitiveWordCreateVo));
        }
        if (serviceResult.hasResult()) {
            return success(mappings.toSensitiveWordVo(serviceResult.getResult()),serviceResult.getAffectedRows());
        }else{
            return failure(ApiCodeEnum.FAIL_CUSTOM,serviceResult.getMessage());
        }
    }

    @SystemLog(value = "敏感词管理:添加了多条记录")
    @PostMapping(value = {"batch"})
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivewordimpl:createbatch')")
    @Operation(summary = "新增多条记录", description = "新增多条记录,返回影响条数及消息")
    protected ResponseResult<List<SensitiveWordVo>> createBatchSensitiveWord(@Validated(value= ValidateInsert.class) @RequestBody ValidList<SensitiveWordCreateVo> sensitiveWordCreateVos) {
        ServiceResult<List<SensitiveWord>> serviceResult = sensitiveWordImpl.insertBatch(mappings.fromSensitiveWordCreateVos(sensitiveWordCreateVos));
        if (serviceResult.hasResult()) {
            return success(mappings.toSensitiveWordVos(serviceResult.getResult()),serviceResult.getAffectedRows());
        }else{
            return failure(ApiCodeEnum.FAIL_CUSTOM,serviceResult.getMessage());
        }
    }

    @SystemLog(value = "敏感词管理:更新了一条记录")
    @PutMapping()
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivewordimpl:update')")
    @Operation(summary = "更新一条记录", description = "根据主键更新数据")
    protected ResponseResult<SensitiveWordVo> updateSensitiveWord(@Validated(value= ValidateUpdate.class) @RequestBody SensitiveWordUpdateVo sensitiveWordUpdateVo) {
        ServiceResult<SensitiveWord> serviceResult = sensitiveWordImpl.updateByPrimaryKeySelective(mappings.fromSensitiveWordUpdateVo(sensitiveWordUpdateVo));
        if (serviceResult.hasResult()) {
            return success(mappings.toSensitiveWordVo(serviceResult.getResult()),serviceResult.getAffectedRows());
        }else{
            return failure(ApiCodeEnum.FAIL_CUSTOM,serviceResult.getMessage());
        }
    }

    @SystemLog(value = "敏感词管理:更新了多条记录")
    @PutMapping(value = {"batch"})
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivewordimpl:updatebatch')")
    @Operation(summary = "批量更新数据", description = "根据主键批量更新数据")
    protected ResponseResult<List<SensitiveWordVo>> updateBatchSensitiveWord(@Validated(value= ValidateUpdate.class) @RequestBody ValidList<SensitiveWordUpdateVo> sensitiveWordUpdateVos) {
        ServiceResult<List<SensitiveWord>> result =  sensitiveWordImpl.updateBatchByPrimaryKey(mappings.fromSensitiveWordUpdateVos(sensitiveWordUpdateVos));
        if (result.hasResult()) {
            return success(mappings.toSensitiveWordVos(result.getResult()),result.getAffectedRows());
        }else{
            return failure(ApiCodeEnum.FAIL_CUSTOM,result.getMessage());
        }
    }

    @SystemLog(value = "敏感词管理:删除了一条记录")
    @DeleteMapping(value = {"{id}"})
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivewordimpl:delete')")
    @Operation(summary = "单条记录删除", description = "根据给定的id删除一条记录")
    protected ResponseResult<Long> deleteSensitiveWord(@PathVariable String id) {
        ServiceResult<Integer> result =  sensitiveWordImpl.deleteByPrimaryKey(id);
        if (result.hasResult() && result.getResult() > 0) {
            return success((long) result.getResult(),result.getAffectedRows());
        } else {
            return failure(ApiCodeEnum.FAIL_CUSTOM,result.getMessage());
        }
    }

    @SystemLog(value = "敏感词管理:删除了一条或多条记录")
    @DeleteMapping()
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivewordimpl:deletebatch')")
    @Operation(summary = "批量记录删除", description = "根据给定的一组id删除多条记录")
    protected ResponseResult<Long> deleteBatchSensitiveWord(@RequestBody List<String> ids) {
        SensitiveWordExample example = new SensitiveWordExample();
        example.createCriteria().andIdIn(ids);
        ServiceResult<Integer> result =  sensitiveWordImpl.deleteByExample(example);
        if (result.hasResult() && result.getResult() > 0) {
            return success((long) result.getResult(),result.getAffectedRows());
        } else {
            return failure(ApiCodeEnum.FAIL_CUSTOM,result.getMessage());
        }
    }

    @SystemLog(value = "敏感词管理:查看表默认视图配置")
    @PostMapping(value = {"dt/view-default"})
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivewordimpl:getdefaultviewconfig')")
    @Operation(summary = "默认数据视图配置", description = "获取默认数据视图配置")
    protected ResponseResult<DataTablesConfig> getDefaultViewConfigSensitiveWord() {
        Optional<ViewDtTableVo> result = DataTablesUtil
                .getSingleViewDtTableByAnnotation(DataTablesUtil.getDefaultViewId("sensitiveWordImpl"), true);
        return result.map(viewDtTableVo -> success(DataTablesMappings.INSTANCE.fromViewDtTableVo(viewDtTableVo)))
                .orElseGet(() -> failure(ApiCodeEnum.FAIL_NOT_FOUND,"默认列表配置"));
    }

    @SystemLog(value = "敏感词管理:查看默认视图")
    @GetMapping(value = {"dt/view-default/show"})
    @PreAuthorize("@uss.hasPermission('sensitive:sensitivewordimpl:getdefaultview')")
    @Operation(summary = "默认数据视图显示", description = "显示默认数据视图")
    protected ModelAndView getDefaultViewSensitiveWord() {
        ModelAndView modelAndView = new ModelAndView("vgoweb/view/DataTables");
        modelAndView.addObject("viewId", DataTablesUtil.getDefaultViewId("sensitiveWordImpl"));
        modelAndView.addObject("listName", "敏感词管理");
        return modelAndView;
    }

    @PostMapping(value = {"select-by-column-ids"})
    @Operation(summary = "根据指定列（多值）获取匹配的记录集合", description = "根据指定列（多值）获取匹配的记录集合接口")
    protected ResponseResult<List<SensitiveWordVo>> selectByColumnIdsSensitiveWord(@RequestBody Map<String, List<String>> paramsMap) {
        List<String> ids = paramsMap.get("ids");
         if (ids.isEmpty()) {
            return ResponseResult.failure(ApiCodeEnum.FAIL_CUSTOM, "id列表不能为空");
        }
        List<SensitiveWord> sensitiveWords = sensitiveWordImpl.selectByColumnIds(ids);
        if (!sensitiveWords.isEmpty()) {
            List<SensitiveWordVo> sensitiveWordVos = mappings.toSensitiveWordVos(sensitiveWords);
            return ResponseResult.success(sensitiveWordVos);
        } else {
            return ResponseResult.failure(ApiCodeEnum.NOT_FOUND, "未找到对应的记录");
        }
    }

    @Override
    protected Page<SensitiveWord> getListData(String beanName, SelectSqlBuilder selectSqlBuilder, List<SensitiveWordVo> returnResult) {
        ServiceResult<List<SensitiveWord>> result = sensitiveWordImpl.selectBySql(selectSqlBuilder);
        if (result.hasResult()) {
            returnResult.addAll(mappings.toSensitiveWordVos(result.getResult()));
        }else{
            returnResult.addAll(new ArrayList<>());
        }
        return (Page<SensitiveWord>) result.getResult();
    }

    protected SensitiveWordExample buildExample(SensitiveWordRequestVo sensitiveWordRequestVo) {
        SensitiveWordExample example = new SensitiveWordExample();
        SensitiveWordExample.Criteria criteria = example.createCriteria();
        if (sensitiveWordRequestVo.isIgnoreDeleteFlag()) {example.setIgnoreDeleteFlag(true);}
        if (sensitiveWordRequestVo.isIgnorePermissionAnnotation()) {example.setIgnorePermissionAnnotation(true);}
        if (!VStringUtil.isBlank(sensitiveWordRequestVo.getId())) {
            if (VStringUtil.indexOf(sensitiveWordRequestVo.getId(), SymbolConstants.COMMA.charAt(0)) > -1) {
                criteria.andIdAnyCondition("regexp '(^|,)(" + sensitiveWordRequestVo.getId().replace(SymbolConstants.COMMA, SymbolConstants.PIPE) + ")(,|$)'" );
            }else{
                criteria.andIdEqualTo(sensitiveWordRequestVo.getId());
            }
        }
        if (sensitiveWordRequestVo.getVersion() != null) {
            criteria.andVersionEqualTo(sensitiveWordRequestVo.getVersion());
        }
        if (sensitiveWordRequestVo.getState() != null) {
            criteria.andStateEqualTo(sensitiveWordRequestVo.getState());
        }
        if (!VStringUtil.isBlank(sensitiveWordRequestVo.getWord())) {
            if (VStringUtil.indexOf(sensitiveWordRequestVo.getWord(), SymbolConstants.COMMA.charAt(0)) > -1) {
                criteria.andWordAnyCondition("regexp '(^|,)(" + sensitiveWordRequestVo.getWord().replace(SymbolConstants.COMMA, SymbolConstants.PIPE) + ")(,|$)'" );
            }else{
                criteria.andWordEqualTo(sensitiveWordRequestVo.getWord());
            }
        }
        if (!VStringUtil.isBlank(sensitiveWordRequestVo.getCategoryId())) {
            if (VStringUtil.indexOf(sensitiveWordRequestVo.getCategoryId(), SymbolConstants.COMMA.charAt(0)) > -1) {
                criteria.andCategoryIdAnyCondition("regexp '(^|,)(" + sensitiveWordRequestVo.getCategoryId().replace(SymbolConstants.COMMA, SymbolConstants.PIPE) + ")(,|$)'" );
            }else{
                criteria.andCategoryIdEqualTo(sensitiveWordRequestVo.getCategoryId());
            }
        }
        if (!VStringUtil.isBlank(sensitiveWordRequestVo.getStrategy())) {
            if (VStringUtil.indexOf(sensitiveWordRequestVo.getStrategy(), SymbolConstants.COMMA.charAt(0)) > -1) {
                criteria.andStrategyAnyCondition("regexp '(^|,)(" + sensitiveWordRequestVo.getStrategy().replace(SymbolConstants.COMMA, SymbolConstants.PIPE) + ")(,|$)'" );
            }else{
                criteria.andStrategyEqualTo(sensitiveWordRequestVo.getStrategy());
            }
        }
        if (!VStringUtil.isBlank(sensitiveWordRequestVo.getNotes())) {
            if (VStringUtil.indexOf(sensitiveWordRequestVo.getNotes(), SymbolConstants.COMMA.charAt(0)) > -1) {
                criteria.andNotesAnyCondition("regexp '(^|,)(" + sensitiveWordRequestVo.getNotes().replace(SymbolConstants.COMMA, SymbolConstants.PIPE) + ")(,|$)'" );
            }else{
                criteria.andNotesEqualTo(sensitiveWordRequestVo.getNotes());
            }
        }
        if (!VStringUtil.isBlank(sensitiveWordRequestVo.getAnyWhereCondition())) {
            criteria.andAnyCondition(sensitiveWordRequestVo.getAnyWhereCondition());
        }
        List<String> orderBy = new ArrayList<>();
        String orderByClause = sensitiveWordRequestVo.getOrderByClause();
        if (VStringUtil.stringHasValue(orderByClause)) {
            orderBy.add(orderByClause);
        } else {
            orderByClause = "";
        }
        if (!orderByClause.toLowerCase().contains(DefaultColumnNameEnum.CREATE_TIME.columnName())) {
            orderBy.add(DefaultColumnNameEnum.CREATE_TIME.columnName()+" desc");
        }
        if (!orderBy.isEmpty()) {
            example.setOrderByClause(String.join(SymbolConstants.COMMA, orderBy));
        }
        return example;
    }

    protected List<Criteria> getCriteriaList(SensitiveWordExample example) {
        List<SensitiveWordExample.Criteria> criteriaList = new ArrayList<>(example.getOredCriteria());
        if (criteriaList.isEmpty()) {
            criteriaList.add(example.createCriteria());
        }
        return criteriaList;
    }
}