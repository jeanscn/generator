package com.vgosoft.sensitive.service.impl;

import com.vgosoft.core.entity.ComSelSqlParameter;
import com.vgosoft.sensitive.dao.SensitiveRuleRevisionMapper;
import com.vgosoft.sensitive.entity.SensitiveRuleRevision;
import com.vgosoft.sensitive.entity.SensitiveRuleRevisionExample;
import com.vgosoft.sensitive.service.impl.SensitiveRuleRevisionImpl;
import com.vgosoft.test.abs.service.AbstractMybatisBGServiceTest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

@ExtendWith(MockitoExtension.class)
public class SensitiveRuleRevisionImplTest extends AbstractMybatisBGServiceTest<SensitiveRuleRevisionImpl, SensitiveRuleRevisionMapper, SensitiveRuleRevision, SensitiveRuleRevisionExample> {
    public SensitiveRuleRevisionImplTest(@Mock SensitiveRuleRevisionMapper mockMapper) {
        super(mockMapper);
    }

    @BeforeEach
    void setUp() {
        this.serviceImplUnderTest = new SensitiveRuleRevisionImpl(mockMapper);
        record = new SensitiveRuleRevision();
        record.setId("id");
        example = new SensitiveRuleRevisionExample();
        comSelSqlParameter = new ComSelSqlParameter();
    }
}