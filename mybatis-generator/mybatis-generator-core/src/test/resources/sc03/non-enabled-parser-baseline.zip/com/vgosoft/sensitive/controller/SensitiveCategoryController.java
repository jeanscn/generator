package com.vgosoft.sensitive.controller;

import com.vgosoft.sensitive.codegen.controller.AbstractSensitiveCategoryController;
import com.vgosoft.sensitive.pojo.maps.SensitiveCategoryMappings;
import com.vgosoft.sensitive.service.ISensitiveCategory;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = {"sensitive/sensitive-category-impl"})
public class SensitiveCategoryController extends AbstractSensitiveCategoryController {
    public SensitiveCategoryController(ISensitiveCategory sensitiveCategoryImpl, SensitiveCategoryMappings mappings) {
        super(sensitiveCategoryImpl, mappings);
    }
}