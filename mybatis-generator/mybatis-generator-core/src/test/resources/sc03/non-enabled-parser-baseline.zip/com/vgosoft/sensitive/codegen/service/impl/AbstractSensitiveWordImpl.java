package com.vgosoft.sensitive.codegen.service.impl;

import com.vgosoft.core.adapter.ServiceResult;
import com.vgosoft.core.constant.enums.core.ServiceCodeEnum;
import com.vgosoft.core.exception.VgoException;
import com.vgosoft.mybatis.abs.AbstractMybatisBGService;
import com.vgosoft.sensitive.codegen.service.IGenSensitiveWord;
import com.vgosoft.sensitive.dao.SensitiveWordMapper;
import com.vgosoft.sensitive.entity.SensitiveWord;
import com.vgosoft.sensitive.entity.SensitiveWordExample;
import com.vgosoft.tool.core.VStringUtil;
import jakarta.annotation.Nullable;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public abstract class AbstractSensitiveWordImpl extends AbstractMybatisBGService<SensitiveWordMapper, SensitiveWord, SensitiveWordExample> implements IGenSensitiveWord {
    private final SensitiveWordMapper mapper;

    public AbstractSensitiveWordImpl(SensitiveWordMapper mapper) {
        super(mapper);
        this.mapper = mapper;
    }

    @Override
    public ServiceResult<List<SensitiveWord>> insertBatch(List<SensitiveWord> sensitiveWords) {
        int i = mapper.insertBatch(sensitiveWords);
        if (i > 0) {
            return ServiceResult.success(sensitiveWords,i);
        }else{
            return ServiceResult.failure(ServiceCodeEnum.WARN);
        }
    }

    @Override
    public ServiceResult<List<SensitiveWord>> updateBatchByPrimaryKey(List<SensitiveWord> sensitiveWords) {
        try {
            int i = mapper.updateBatchByPrimaryKey(sensitiveWords);
            return ServiceResult.success(sensitiveWords, i);
        } catch (Exception e) {
            throw new VgoException(ServiceCodeEnum.FAIL.code(), e.getMessage());
        }
    }

    /**
     * 根据完整主键锁定并查询记录。
     * 必须在非只读既有事务中调用；锁持有至事务结束，数据库异常直接向外传播。
     * 不经过查询缓存；可见版本取决于数据库和事务隔离级别。
     * @param id 完整主键值
     * @return 锁定查询结果的服务包装
     * @throws IllegalStateException 未开启事务、只读事务或存在分页上下文
     * @throws IllegalArgumentException 查询条件不符合锁定查询约束
     */
    @Override
    @org.springframework.transaction.annotation.Transactional(propagation = org.springframework.transaction.annotation.Propagation.MANDATORY, rollbackFor = Exception.class)
    public ServiceResult<SensitiveWord> selectByPrimaryKeyForUpdate(String id) {
        com.vgosoft.sensitive.codegen.dao.GenSensitiveWordMapperLockQueryGuard.requireSelectForUpdateTransaction();
        return ServiceResult.success(mapper.selectByPrimaryKeyForUpdate(id));
    }

    /**
     * 根据明确条件锁定并查询记录，禁止全表、去重、动态排序和分页。
     * 必须在非只读既有事务中调用；锁持有至事务结束，数据库异常直接向外传播。
     * 不经过查询缓存；可见版本取决于数据库和事务隔离级别。
     * @param example 非空白名单查询条件
     * @return 锁定查询结果的服务包装
     * @throws IllegalStateException 未开启事务、只读事务或存在分页上下文
     * @throws IllegalArgumentException 查询条件不符合锁定查询约束
     */
    @Override
    @org.springframework.transaction.annotation.Transactional(propagation = org.springframework.transaction.annotation.Propagation.MANDATORY, rollbackFor = Exception.class)
    public ServiceResult<List<SensitiveWord>> selectByExampleForUpdate(SensitiveWordExample example) {
        com.vgosoft.sensitive.codegen.dao.GenSensitiveWordMapperLockQueryGuard.requireSelectForUpdateTransaction();
        com.vgosoft.sensitive.codegen.dao.GenSensitiveWordMapperLockQueryGuard.requireSelectForUpdateExample(example);
        return ServiceResult.success(mapper.selectByExampleForUpdate(example));
    }

    @Override
    public Integer updateDeleteFlag(SensitiveWord sensitiveWord, int deleteFlag) {
        sensitiveWord.setDeleteFlag(deleteFlag);
        return mapper.updateByPrimaryKey(sensitiveWord);
    }

    @Override
    public ServiceResult<SensitiveWord> insertOrUpdate(SensitiveWord sensitiveWord) {
        try {
            int i = mapper.insertOrUpdate(sensitiveWord);
            return ServiceResult.success(sensitiveWord,i);
        } catch (Exception e) {
            throw new VgoException(ServiceCodeEnum.FAIL.code(), e.getMessage());
        }
    }

    @Override
    public List<SensitiveWord> selectByColumnIds(List<String> ids) {
        return mapper.selectByColumnIds(ids);
    }

    @Override
    public List<SensitiveWord> selectByPrimaryKeys(@Nullable String ids) {
        if (!VStringUtil.stringHasValue(ids)) {
            return this.selectByExample(new SensitiveWordExample()).getResult();
        } else {
            return Arrays.stream(ids.split(","))
                    .map(this::selectByPrimaryKey)
                    .filter(ServiceResult::hasResult)
                    .map(ServiceResult::getResult)
                    .collect(Collectors.toList());
        }
    }
}