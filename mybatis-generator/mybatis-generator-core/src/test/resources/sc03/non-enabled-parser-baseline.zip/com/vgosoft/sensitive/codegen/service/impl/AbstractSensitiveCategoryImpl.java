package com.vgosoft.sensitive.codegen.service.impl;

import com.vgosoft.core.adapter.ServiceResult;
import com.vgosoft.core.constant.enums.core.ServiceCodeEnum;
import com.vgosoft.core.exception.VgoException;
import com.vgosoft.mybatis.abs.AbstractMybatisBGService;
import com.vgosoft.sensitive.codegen.service.IGenSensitiveCategory;
import com.vgosoft.sensitive.dao.SensitiveCategoryMapper;
import com.vgosoft.sensitive.entity.SensitiveCategory;
import com.vgosoft.sensitive.entity.SensitiveCategoryExample;
import com.vgosoft.tool.core.VStringUtil;
import jakarta.annotation.Nullable;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public abstract class AbstractSensitiveCategoryImpl extends AbstractMybatisBGService<SensitiveCategoryMapper, SensitiveCategory, SensitiveCategoryExample> implements IGenSensitiveCategory {
    private final SensitiveCategoryMapper mapper;

    public AbstractSensitiveCategoryImpl(SensitiveCategoryMapper mapper) {
        super(mapper);
        this.mapper = mapper;
    }

    @Override
    public ServiceResult<List<SensitiveCategory>> insertBatch(List<SensitiveCategory> sensitiveCategorys) {
        int i = mapper.insertBatch(sensitiveCategorys);
        if (i > 0) {
            return ServiceResult.success(sensitiveCategorys,i);
        }else{
            return ServiceResult.failure(ServiceCodeEnum.WARN);
        }
    }

    @Override
    public ServiceResult<List<SensitiveCategory>> updateBatchByPrimaryKey(List<SensitiveCategory> sensitiveCategorys) {
        try {
            int i = mapper.updateBatchByPrimaryKey(sensitiveCategorys);
            return ServiceResult.success(sensitiveCategorys, i);
        } catch (Exception e) {
            throw new VgoException(ServiceCodeEnum.FAIL.code(), e.getMessage());
        }
    }

    /**
     * 根据完整主键锁定并查询记录。
     * 必须在非只读既有事务中调用；锁持有至事务结束，数据库异常直接向外传播。
     * 不经过查询缓存；可见版本取决于数据库和事务隔离级别。
     * @param id 完整主键值
     * @return 锁定查询结果的服务包装
     * @throws IllegalStateException 未开启事务、只读事务或存在分页上下文
     * @throws IllegalArgumentException 查询条件不符合锁定查询约束
     */
    @Override
    @org.springframework.transaction.annotation.Transactional(propagation = org.springframework.transaction.annotation.Propagation.MANDATORY, rollbackFor = Exception.class)
    public ServiceResult<SensitiveCategory> selectByPrimaryKeyForUpdate(String id) {
        com.vgosoft.sensitive.codegen.dao.GenSensitiveCategoryMapperLockQueryGuard.requireSelectForUpdateTransaction();
        return ServiceResult.success(mapper.selectByPrimaryKeyForUpdate(id));
    }

    /**
     * 根据明确条件锁定并查询记录，禁止全表、去重、动态排序和分页。
     * 必须在非只读既有事务中调用；锁持有至事务结束，数据库异常直接向外传播。
     * 不经过查询缓存；可见版本取决于数据库和事务隔离级别。
     * @param example 非空白名单查询条件
     * @return 锁定查询结果的服务包装
     * @throws IllegalStateException 未开启事务、只读事务或存在分页上下文
     * @throws IllegalArgumentException 查询条件不符合锁定查询约束
     */
    @Override
    @org.springframework.transaction.annotation.Transactional(propagation = org.springframework.transaction.annotation.Propagation.MANDATORY, rollbackFor = Exception.class)
    public ServiceResult<List<SensitiveCategory>> selectByExampleForUpdate(SensitiveCategoryExample example) {
        com.vgosoft.sensitive.codegen.dao.GenSensitiveCategoryMapperLockQueryGuard.requireSelectForUpdateTransaction();
        com.vgosoft.sensitive.codegen.dao.GenSensitiveCategoryMapperLockQueryGuard.requireSelectForUpdateExample(example);
        return ServiceResult.success(mapper.selectByExampleForUpdate(example));
    }

    @Override
    public Integer updateDeleteFlag(SensitiveCategory sensitiveCategory, int deleteFlag) {
        sensitiveCategory.setDeleteFlag(deleteFlag);
        return mapper.updateByPrimaryKey(sensitiveCategory);
    }

    @Override
    public ServiceResult<SensitiveCategory> insertOrUpdate(SensitiveCategory sensitiveCategory) {
        try {
            int i = mapper.insertOrUpdate(sensitiveCategory);
            return ServiceResult.success(sensitiveCategory,i);
        } catch (Exception e) {
            throw new VgoException(ServiceCodeEnum.FAIL.code(), e.getMessage());
        }
    }

    @Override
    public List<SensitiveCategory> selectByColumnIds(List<String> ids) {
        return mapper.selectByColumnIds(ids);
    }

    @Override
    public List<SensitiveCategory> selectByPrimaryKeys(@Nullable String ids) {
        if (!VStringUtil.stringHasValue(ids)) {
            return this.selectByExample(new SensitiveCategoryExample()).getResult();
        } else {
            return Arrays.stream(ids.split(","))
                    .map(this::selectByPrimaryKey)
                    .filter(ServiceResult::hasResult)
                    .map(ServiceResult::getResult)
                    .collect(Collectors.toList());
        }
    }
}