package com.vgosoft.sensitive.codegen.dao;

import com.vgosoft.sensitive.entity.SensitiveCategoryExample;

/**
 * 锁定查询的事务、分页和条件门禁，仅用于生成的独立锁定查询。
 * @author vgosoft
 */
public final class GenSensitiveCategoryMapperLockQueryGuard {
    /**
     * 验证非只读既有事务及无分页上下文，禁止绕过 Service 的直接 Mapper 调用。
     * @return 门禁验证通过
     * @throws IllegalStateException 无事务、只读事务或存在分页上下文
     */
    public static boolean requireSelectForUpdateTransaction() {
        if (!org.springframework.transaction.support.TransactionSynchronizationManager.isActualTransactionActive()
                || org.springframework.transaction.support.TransactionSynchronizationManager.isCurrentTransactionReadOnly()) {
            throw new IllegalStateException("锁定查询必须在非只读既有事务中执行");
        }
        if (com.github.pagehelper.PageHelper.getLocalPage() != null) {
            throw new IllegalStateException("锁定查询禁止 PageHelper 分页或排序上下文");
        }
        return true;
    }

    /**
     * 校验非空条件及内省列操作符白名单，拒绝原始 SQL、去重和任意排序。
     * @param example 非空标准查询条件
     * @return 门禁验证通过
     * @throws IllegalStateException 无事务、只读事务或存在分页上下文
     * @throws IllegalArgumentException 查询条件不符合锁定查询约束
     */
    public static boolean requireSelectForUpdateExample(SensitiveCategoryExample example) {
        requireSelectForUpdateTransaction();
        if (example == null || example.isDistinct() || example.getOrderByClause() != null
                || example.getOredCriteria() == null || example.getOredCriteria().isEmpty()) {
            throw new IllegalArgumentException("锁定查询要求非空条件，禁止 DISTINCT 和动态排序");
        }
        java.util.Set<String> allowed = new java.util.HashSet<>(java.util.Arrays.asList("sc.id_ is null", "sc.id_ is not null", "sc.id_ =", "sc.id_ <>", "sc.id_ >", "sc.id_ >=", "sc.id_ <", "sc.id_ <=", "sc.id_ like", "sc.id_ not like", "sc.id_ in", "sc.id_ not in", "sc.id_ between", "sc.id_ not between", "sc.delete_flag is null", "sc.delete_flag is not null", "sc.delete_flag =", "sc.delete_flag <>", "sc.delete_flag >", "sc.delete_flag >=", "sc.delete_flag <", "sc.delete_flag <=", "sc.delete_flag like", "sc.delete_flag not like", "sc.delete_flag in", "sc.delete_flag not in", "sc.delete_flag between", "sc.delete_flag not between", "sc.created_ is null", "sc.created_ is not null", "sc.created_ =", "sc.created_ <>", "sc.created_ >", "sc.created_ >=", "sc.created_ <", "sc.created_ <=", "sc.created_ like", "sc.created_ not like", "sc.created_ in", "sc.created_ not in", "sc.created_ between", "sc.created_ not between", "sc.modified_ is null", "sc.modified_ is not null", "sc.modified_ =", "sc.modified_ <>", "sc.modified_ >", "sc.modified_ >=", "sc.modified_ <", "sc.modified_ <=", "sc.modified_ like", "sc.modified_ not like", "sc.modified_ in", "sc.modified_ not in", "sc.modified_ between", "sc.modified_ not between", "sc.created_id is null", "sc.created_id is not null", "sc.created_id =", "sc.created_id <>", "sc.created_id >", "sc.created_id >=", "sc.created_id <", "sc.created_id <=", "sc.created_id like", "sc.created_id not like", "sc.created_id in", "sc.created_id not in", "sc.created_id between", "sc.created_id not between", "sc.modified_id is null", "sc.modified_id is not null", "sc.modified_id =", "sc.modified_id <>", "sc.modified_id >", "sc.modified_id >=", "sc.modified_id <", "sc.modified_id <=", "sc.modified_id like", "sc.modified_id not like", "sc.modified_id in", "sc.modified_id not in", "sc.modified_id between", "sc.modified_id not between", "sc.version_ is null", "sc.version_ is not null", "sc.version_ =", "sc.version_ <>", "sc.version_ >", "sc.version_ >=", "sc.version_ <", "sc.version_ <=", "sc.version_ like", "sc.version_ not like", "sc.version_ in", "sc.version_ not in", "sc.version_ between", "sc.version_ not between", "sc.sort_ is null", "sc.sort_ is not null", "sc.sort_ =", "sc.sort_ <>", "sc.sort_ >", "sc.sort_ >=", "sc.sort_ <", "sc.sort_ <=", "sc.sort_ like", "sc.sort_ not like", "sc.sort_ in", "sc.sort_ not in", "sc.sort_ between", "sc.sort_ not between", "sc.state_ is null", "sc.state_ is not null", "sc.state_ =", "sc.state_ <>", "sc.state_ >", "sc.state_ >=", "sc.state_ <", "sc.state_ <=", "sc.state_ like", "sc.state_ not like", "sc.state_ in", "sc.state_ not in", "sc.state_ between", "sc.state_ not between", "sc.code_ is null", "sc.code_ is not null", "sc.code_ =", "sc.code_ <>", "sc.code_ >", "sc.code_ >=", "sc.code_ <", "sc.code_ <=", "sc.code_ like", "sc.code_ not like", "sc.code_ in", "sc.code_ not in", "sc.code_ between", "sc.code_ not between", "sc.code_hash_ is null", "sc.code_hash_ is not null", "sc.code_hash_ =", "sc.code_hash_ <>", "sc.code_hash_ >", "sc.code_hash_ >=", "sc.code_hash_ <", "sc.code_hash_ <=", "sc.code_hash_ like", "sc.code_hash_ not like", "sc.code_hash_ in", "sc.code_hash_ not in", "sc.code_hash_ between", "sc.code_hash_ not between", "sc.name_ is null", "sc.name_ is not null", "sc.name_ =", "sc.name_ <>", "sc.name_ >", "sc.name_ >=", "sc.name_ <", "sc.name_ <=", "sc.name_ like", "sc.name_ not like", "sc.name_ in", "sc.name_ not in", "sc.name_ between", "sc.name_ not between", "sc.notes_ is null", "sc.notes_ is not null", "sc.notes_ =", "sc.notes_ <>", "sc.notes_ >", "sc.notes_ >=", "sc.notes_ <", "sc.notes_ <=", "sc.notes_ like", "sc.notes_ not like", "sc.notes_ in", "sc.notes_ not in", "sc.notes_ between", "sc.notes_ not between"));
        boolean valid = false;
        for (SensitiveCategoryExample.Criteria criteria : example.getOredCriteria()) {
            if (criteria == null) { throw new IllegalArgumentException("锁定查询条件组不能为空"); }
            if (!criteria.isValid()) { continue; }
            for (SensitiveCategoryExample.Criterion criterion : criteria.getAllCriteria()) {
                if (criterion == null || !allowed.contains(criterion.getCondition())) {
                    throw new IllegalArgumentException("锁定查询只允许内省列的标准条件，禁止原始 SQL");
                }
                if (criterion.isListValue() && (!(criterion.getValue() instanceof java.util.List)
                        || ((java.util.List<?>) criterion.getValue()).isEmpty())) {
                    throw new IllegalArgumentException("锁定查询的集合条件不能为空");
                }
                valid = true;
            }
        }
        if (!valid) { throw new IllegalArgumentException("锁定查询禁止无条件整表查询"); }
        return true;
    }
}