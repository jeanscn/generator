package com.vgosoft.sensitive.codegen.service;

import com.vgosoft.core.adapter.ServiceResult;
import com.vgosoft.mybatis.inf.IMybatisBGService;
import com.vgosoft.sensitive.entity.SensitiveWord;
import com.vgosoft.sensitive.entity.SensitiveWordExample;
import jakarta.annotation.Nullable;
import java.util.List;

public interface IGenSensitiveWord extends IMybatisBGService<SensitiveWord, SensitiveWordExample> {
    /**
     * 根据完整主键锁定并查询记录。
     * 必须在非只读既有事务中调用；锁持有至事务结束，数据库异常直接向外传播。
     * 不经过查询缓存；可见版本取决于数据库和事务隔离级别。
     * @param id 完整主键值
     * @return 锁定查询结果的服务包装
     * @throws IllegalStateException 未开启事务、只读事务或存在分页上下文
     * @throws IllegalArgumentException 查询条件不符合锁定查询约束
     */
    ServiceResult<SensitiveWord> selectByPrimaryKeyForUpdate(String id);

    /**
     * 根据明确条件锁定并查询记录，禁止全表、去重、动态排序和分页。
     * 必须在非只读既有事务中调用；锁持有至事务结束，数据库异常直接向外传播。
     * 不经过查询缓存；可见版本取决于数据库和事务隔离级别。
     * @param example 非空白名单查询条件
     * @return 锁定查询结果的服务包装
     * @throws IllegalStateException 未开启事务、只读事务或存在分页上下文
     * @throws IllegalArgumentException 查询条件不符合锁定查询约束
     */
    ServiceResult<List<SensitiveWord>> selectByExampleForUpdate(SensitiveWordExample example);

    ServiceResult<List<SensitiveWord>> insertBatch(List<SensitiveWord> sensitiveWords);

    ServiceResult<List<SensitiveWord>> updateBatchByPrimaryKey(List<SensitiveWord> sensitiveWords);

    Integer updateDeleteFlag(SensitiveWord sensitiveWord, int deleteFlag);

    ServiceResult<SensitiveWord> insertOrUpdate(SensitiveWord sensitiveWord);

    List<SensitiveWord> selectByColumnIds(List<String> ids);

    List<SensitiveWord> selectByPrimaryKeys(@Nullable String ids);
}