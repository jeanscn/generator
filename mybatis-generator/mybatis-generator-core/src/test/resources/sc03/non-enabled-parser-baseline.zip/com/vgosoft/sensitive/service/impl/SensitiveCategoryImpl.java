package com.vgosoft.sensitive.service.impl;

import com.vgosoft.sensitive.codegen.service.impl.AbstractSensitiveCategoryImpl;
import com.vgosoft.sensitive.dao.SensitiveCategoryMapper;
import com.vgosoft.sensitive.service.ISensitiveCategory;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

@Service("sensitiveCategoryImpl")
@Primary
public class SensitiveCategoryImpl extends AbstractSensitiveCategoryImpl implements ISensitiveCategory {
    public SensitiveCategoryImpl(SensitiveCategoryMapper mapper) {
        super(mapper);
    }
}